CREATE TABLE trn_author
			(
				  id INT PRIMARY KEY
				, salutation VARCHAR(20)
				, first_name VARCHAR(20)
				);

INSERT INTO trn_author VALUES(1,"Mrs","J.K.Rowling");
INSERT INTO trn_author VALUES(2,"Mr","Chetan");
INSERT INTO trn_author VALUES(3,"Mr","A.P.J.Kalam");


CREATE TABLE trn_publication (id INT PRIMARY KEY
                     ,publisher VARCHAR(25));
					 
INSERT INTO trn_publication VALUES(1,"Penguin");
INSERT INTO trn_publication VALUES(3,"Bloomsbury");
INSERT INTO trn_publication VALUES(2,"Rupa Publications");	

CREATE TABLE trn_movie
			(
				  id INT PRIMARY KEY
				, film VARCHAR(20)		
			);
INSERT INTO trn_movie VALUES(1,"two states");
INSERT INTO trn_movie VALUES(2,"Harry Potter Vol 1");
INSERT INTO trn_movie VALUES(3,"Harry Potter Vol 2");
INSERT INTO trn_movie VALUES(4,"Harry Potter Vol 3");
INSERT INTO trn_movie VALUES(5,"Harry Potter Vol 4");

CREATE TABLE trn_book
			(
				  id INT PRIMARY KEY
				, title VARCHAR(20)
				, quantity INT 
				, trn_author_id INT 
				, KEY FK (trn_author_id)
				, CONSTRAINT FK_constraint FOREIGN KEY (trn_author_id) REFERENCES trn_author (id) ON DELETE NO ACTION ON UPDATE NO ACTION
				
			);

INSERT INTO trn_book VALUES(101,"Two states",1,2);
INSERT INTO trn_book VALUES(102,"India 2020",1,3);
INSERT INTO trn_book VALUES(103,"Harry potter vol 1",1,1);
INSERT INTO trn_book VALUES(104,"Harry potter vol 2",1,1);
INSERT INTO trn_book VALUES(106,"Harry potter vol 3",1,1);
INSERT INTO trn_book VALUES(105,"Harry potter vol 4",1,1);


CREATE VIEW trn_view1 (author_id,salutation,first_name) AS SELECT * FROM trn_author;

