UPDATE edu_semester_fee SET paid_years='2018' AND paid_status="PAID" 
  WHERE student_id=(SELECT id FROM edu_student WHERE roll_number= 411720); 

UPDATE edu_semester_fee SET paid_years='2018' AND paid_status="PAID" 
  WHERE student_id IN(SELECT id FROM edu_student WHERE roll_number IN(411720,411930,411679)); 