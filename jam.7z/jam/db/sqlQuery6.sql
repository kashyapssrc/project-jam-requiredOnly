INSERT INTO edu_semester_fee(semester, paid_status, college_dept_id, student_id)
  VALUES(3, "NOT PAID", 1001, 7001)
      , (3, "NOT PAID", 1001, 7002)	
		, (3, "NOT PAID", 1001, 7003)	
	   , (3, "NOT PAID", 1001, 7004)	
		, (3, "NOT PAID", 1001, 7005)
		, (3, "NOT PAID", 1001, 7006)	
		, (3, "NOT PAID", 1001, 7007)	
		, (3, "NOT PAID", 1001, 7008)
		, (3, "NOT PAID", 1001, 7009);	
		
		  
