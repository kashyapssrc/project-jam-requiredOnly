UPDATE edu_semester_fee SET amount=18000 WHERE semester=1;
UPDATE edu_semester_fee SET amount=18500 WHERE semester=2;
UPDATE edu_semester_fee SET amount=18700 WHERE semester=3;

SELECT SUM(amount),uni.university_name, col.college_name FROM edu_semester_fee AS sem 
 INNER JOIN edu_college_department AS cdept ON sem.college_dept_id=cdept.college_dept_id
 INNER JOIN edu_college AS col ON col.id=cdept.college_id
 INNER JOIN edu_university AS uni ON col.univ_code=uni.univ_code
  WHERE uni.univ_code='AU' GROUP BY col.college_name;
  
SELECT SUM(amount), uni.university_name, col.college_name FROM edu_semester_fee AS sem 
 INNER JOIN edu_college_department AS cdept ON sem.college_dept_id=cdept.college_dept_id
 INNER JOIN edu_college AS col ON col.id=cdept.college_id
 INNER JOIN edu_university AS uni ON col.univ_code=uni.univ_code
  WHERE uni.univ_code='AU' AND sem.paid_years="2018" AND paid_status="PAID" ;
  
SELECT SUM(amount),col.college_name FROM edu_semester_fee AS sem 
 INNER JOIN edu_college_department AS cdept ON sem.college_dept_id=cdept.college_dept_id
 INNER JOIN edu_college AS col ON col.id=cdept.college_id
 INNER JOIN edu_university AS uni ON col.univ_code=uni.univ_code
  WHERE uni.univ_code='AU' AND paid_status="NOT_PAID";
  
