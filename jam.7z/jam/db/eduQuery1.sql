SELECT col.college_code, col.college_name, uni.university_name, col.city, col.state, col.year_opened
      , dept.department_name, emp.employee_name AS HOD_name FROM edu_university AS uni 
  INNER JOIN edu_college AS col ON uni.univ_code=col.univ_code 
  INNER JOIN edu_college_department AS cdep ON cdep.college_id=col.id
  INNER JOIN edu_department AS dept ON cdep.univ_dept_code=dept.department_code 
  INNER JOIN edu_employee AS emp ON emp.college_dept_id=cdep.college_dept_id
     WHERE emp.designation_id=(SELECT id FROM edu_designation WHERE designation_name="HOD") 
	   AND department_code IN('CS','IT','CS1','IT1','CS2','IT2','CS3','IT3','CS4','IT4');
