ALTER TABLE trn_author ADD(rating INT);

INSERT INTO trn_author VALUES(5,"Mr","Dan Brown",3);
INSERT INTO trn_author VALUES(7,"Mrs","Agatha cristie",3);
INSERT INTO trn_author VALUES(8,"Ms","David Kelly",2);
INSERT INTO trn_author VALUES(9,"Mr","George Martin",2);

ALTER VIEW trn_view1(id,salutation,first_name,rating) AS SELECT * FROM trn_author;

ALTER TABLE trn_book
    ADD trn_publisher_id INTEGER,
    ADD CONSTRAINT FOREIGN KEY(trn_publisher_id) REFERENCES trn_publication(id);
    
ALTER TABLE trn_book
    ADD trn_movie_id INTEGER,
    ADD CONSTRAINT FOREIGN KEY(trn_movie_id) REFERENCES trn_movie(id);
    
CREATE VIEW trn_view2
AS
SELECT  b.id id,
        b.title title,
        a.first_name author_name,
        p.publisher publication_name,
        m.film movie_inspired
   FROM trn_book b
        INNER JOIN trn_author a
            ON b.trn_author_id = a.id
        INNER JOIN trn_publication p
            ON b.trn_publisher_id= p.id
        INNER JOIN trn_movie m
            ON b.trn_movie_id = m.id;