SELECT desg.designation_name, desg.rank, col.college_name, dept.department_name, uni.univ_code, uni.university_name FROM edu_employee AS emp
  INNER JOIN edu_designation AS desg ON emp.designation_id= desg.id
  INNER JOIN edu_college AS col ON emp.college_id= col.id
  INNER JOIN edu_college_department AS cdep ON cdep.college_id=col.id
  INNER JOIN edu_department AS dept ON cdep.univ_dept_code=dept.department_code
  INNER JOIN edu_university AS uni ON dept.univ_code=uni.univ_code
    WHERE emp.designation_id=(SELECT designation_id FROM edu_designation WHERE desg.id=NULL);