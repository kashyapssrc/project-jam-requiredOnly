UPDATE trn_author SET rating = 5 WHERE first_name="A.P.J.Kalam";
UPDATE trn_author SET rating = 3 WHERE first_name="J.K.Rowling";
UPDATE trn_author SET rating = 2 WHERE first_name="Chetan";

UPDATE trn_book SET quantity=2 WHERE id=102;

UPDATE trn_book SET trn_author_id = 8 WHERE id=109;
UPDATE trn_book SET trn_author_id = 9 WHERE id=110;

UPDATE trn_book
SET    trn_publisher_id = 
       CASE id
            WHEN 101 THEN 1
            WHEN 102 THEN 2
            WHEN 103 THEN 3
            WHEN 104 THEN 3
            WHEN 105 THEN 3
            WHEN 106 THEN 3    
       END
WHERE  id IN (101,102,103,104,105,106);

UPDATE trn_book SET trn_publisher_id = 1 WHERE id=109;
UPDATE trn_book SET trn_publisher_id = 3 WHERE id=110;					 

UPDATE trn_book
SET trn_movie_id = 
       CASE id
            WHEN 101 THEN 1
            WHEN 103 THEN 2
            WHEN 104 THEN 3
            WHEN 105 THEN 4
            WHEN 106 THEN 5    
       END
WHERE id IN (101,103,104,105,106);