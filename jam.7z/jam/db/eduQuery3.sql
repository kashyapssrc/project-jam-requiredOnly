SELECT  stu.roll_number, stu.student_name, stu.gender, stu.date_of_birth, stu.email, stu.phone, stu.address
           , col.college_name, dept.department_name, emp.employee_name AS HOD_name FROM edu_student AS stu 
  INNER  JOIN edu_college AS col ON stu.college_id=col.id
  INNER  JOIN edu_university AS uni ON uni.univ_code=col.univ_code
  INNER  JOIN edu_college_department AS cdep
  INNER  JOIN edu_department AS dept ON cdep.univ_dept_code=dept.department_code
  INNER  JOIN edu_employee AS emp ON emp.college_dept_id=cdep.college_dept_id
  INNER  JOIN edu_designation AS des ON emp.designation_id=des.id
   WHERE uni.univ_code='AU' AND col.city IN ("Chennai","Pondicherry") AND des.designation_name="HOD"
	ORDER BY col.college_name LIMIT 20 OFFSET 20;  