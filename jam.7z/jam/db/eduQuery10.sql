SELECT stu.id, stu.student_name, stu.date_of_birth, res.semester, res.grade, res.credit, res.result_date FROM edu_student AS stu 
  INNER JOIN edu_semester_result AS res ON stu.id=res.student_id
    WHERE res.credit > 8 AND res.semester=1 
	   OR  res.credit > 5 AND res.semester=3;
    