SELECT stu.id, stu.student_name, stu.academic_year, stu.college_dept_id, stu.college_id, res.grade, res.credit
      , col.college_name, univ.university_name, res.semester FROM edu_student AS stu 
  INNER JOIN edu_semester_result AS res ON stu.id=res.student_id
  INNER JOIN edu_college AS col ON stu.college_id=col.id
  INNER JOIN edu_university AS univ ON col.univ_code=univ.univ_code
    ORDER BY col.college_name, res.semester DESC 
	   LIMIT 20 OFFSET 20;
    