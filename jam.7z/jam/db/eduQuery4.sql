SELECT DISTINCT emp.id, emp.employee_name, emp.date_of_birth, emp.email, emp.phone, emp.college_id, emp.college_dept_id, emp.designation_id, des.rank ,col.college_name FROM edu_employee AS emp 
  INNER JOIN edu_college AS col ON emp.college_id=col.id 
  INNER JOIN edu_university AS uni ON uni.univ_code=col.univ_code 
  INNER JOIN edu_department AS dept ON dept.univ_code=uni.univ_code
  INNER JOIN edu_designation AS des ON des.id=emp.designation_id
    WHERE uni.univ_code='AU' ORDER BY des.rank, col.college_name  ;