SELECT stu.roll_number, stu.student_name, stu.gender, stu.date_of_birth, stu.email
       , stu.phone, stu.address, col.college_name , dept.department_name FROM edu_student AS stu 
  INNER  JOIN edu_semester_fee AS sem ON stu.id=sem.student_id
  INNER  JOIN edu_college AS col ON stu.college_id=col.id
  INNER  JOIN edu_college_department AS cdep ON cdep.college_dept_id=stu.college_dept_id
  INNER  JOIN edu_department AS dept ON dept.department_code=cdep.univ_dept_code
   WHERE sem.semester IN (3,4);