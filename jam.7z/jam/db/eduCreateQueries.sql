CREATE TABLE edu_university(
                             univ_code CHAR(4) PRIMARY KEY
									, university_name VARCHAR(100) NOT NULL
									);
CREATE TABLE edu_college(
                           id INT PRIMARY KEY
                         , college_code CHAR(4) NOT NULL
                         , college_name VARCHAR(100) NOT NULL
                         , city VARCHAR(50) NOT NULL
                         , state VARCHAR(50) NOT NULL
                         , year_opened YEAR(4) NOT NULL
                         , univ_code CHAR(4)
                         , CONSTRAINT `fk_edu_university_edu_college` FOREIGN KEY(univ_code) REFERENCES edu_university(univ_code)
								);
															
CREATE TABLE edu_department(
                             department_code CHAR(4) PRIMARY KEY
                           , department_name VARCHAR(50) NOT NULL
                           , univ_code CHAR(4)
                           , CONSTRAINT `fk_edu_university_edu_department` FOREIGN KEY(univ_code) REFERENCES edu_university(univ_code)
									);				
CREATE TABLE edu_college_department(
                                      college_dept_id INT PRIMARY KEY
												, college_id INT
												, univ_dept_code CHAR(4)
												, CONSTRAINT `fk_edu_college_edu_college_department` FOREIGN KEY(college_id) REFERENCES edu_college(id)
												, CONSTRAINT `fk_edu_college_edu_department` FOREIGN KEY(univ_dept_code) REFERENCES edu_department(department_code)				
												);	
CREATE TABLE edu_designation(
                               id INT PRIMARY KEY
                             , designation_name VARCHAR(30) NOT NULL
                             , rank CHAR(4) NOT NULL 
									);		
CREATE TABLE edu_employee(
                            id INT PRIMARY KEY
                          , employee_name VARCHAR(100) NOT NULL
								  , date_of_birth DATE NOT NULL
								  , email VARCHAR(50) NOT NULL
								  , phone BIGINT NOT NULL
								  , college_id INT
								  , college_dept_id INT
								  , designation_id INT 
								  , CONSTRAINT `fk_edu_college_edu_employee` FOREIGN KEY(college_id) REFERENCES edu_college(id)
								  , CONSTRAINT `fk_edu_college_department_edu_employee` FOREIGN KEY(college_dept_id) REFERENCES edu_college_department(college_dept_id)
								  , CONSTRAINT `fk_edu_designation_edu_employee` FOREIGN KEY(designation_id) REFERENCES edu_designation(id)
                          );			
CREATE TABLE edu_syllabus(
                        id INT PRIMARY KEY
							 , syllabus_code CHAR(4) NOT NULL
							 , syllabus_name VARCHAR(100) NOT NULL
							 , college_dept_id INT
							 , CONSTRAINT `fk_edu_college_department_edu_syllabus` FOREIGN KEY(college_dept_id) REFERENCES edu_college_department(college_dept_id)
							 );	
CREATE TABLE edu_professor_syllabus(
                                  semester TINYINT NOT NULL
										  , employee_id INT
										  , syllabus_id INT
										  , CONSTRAINT `fk_edu_employee_edu_professor_syllabus` FOREIGN KEY(employee_id) REFERENCES edu_employee(id)
										  , CONSTRAINT `fk_edu_syllabus_edu_professor_syllabus` FOREIGN KEY(syllabus_id) REFERENCES edu_syllabus(id)
										  );		
CREATE TABLE edu_student(
                           id INT PRIMARY KEY
								 , roll_number CHAR(8) NOT NULL
								 , student_name VARCHAR(100) NOT NULL
								 , date_of_birth DATE NOT NULL
								 , gender CHAR(1) NOT NULL
								 , email VARCHAR(50) NOT NULL
								 , phone BIGINT NOT NULL
								 , address VARCHAR(200) NOT NULL
								 , academic_year YEAR(4) NOT NULL
								 , college_dept_id INT
								 , college_id INT
								 , CONSTRAINT `fk_edu_college_department_edu_student` FOREIGN KEY(college_dept_id) REFERENCES edu_college_department(college_dept_id)
								 , CONSTRAINT `fk_edu_college_edu_student` FOREIGN KEY(college_id) REFERENCES edu_college(id)
								 );							
CREATE TABLE edu_semester_fee(
                                 semester TINYINT NOT NULL
                               , amount DOUBLE(18,2) NULL
                               , paid_years YEAR(4) NULL
                               , paid_status VARCHAR(10) NOT NULL
                               , college_dept_id INT
                               , student_id INT
                               , CONSTRAINT `fk_edu_college_department_edu_semester_fee` FOREIGN KEY(college_dept_id) REFERENCES edu_college_department(college_dept_id)
										 , CONSTRAINT `fk_edu_student_edu_semester_fee` FOREIGN KEY(student_id) REFERENCES edu_student(id) 
                               );	
CREATE TABLE edu_semester_result(
                                   semester TINYINT NOT NULL
											, grade VARCHAR(2) NOT NULL
											, credit FLOAT NOT NULL
											, result_date DATE NOT NULL
											, student_id INT
											, syllabus_id INT 
											, CONSTRAINT `fk_edu_student_edu_semester_result` FOREIGN KEY(student_id) REFERENCES edu_student(id)
											, CONSTRAINT `fk_edu_syllabus_edu_semester_result` FOREIGN KEY(syllabus_id) REFERENCES edu_syllabus(id)
											);		
								 							 			  					 							  															 