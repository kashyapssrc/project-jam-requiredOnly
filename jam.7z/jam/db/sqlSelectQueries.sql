SELECT * FROM trn_author;
SELECT * FROM trn_book;	
SELECT id FROM trn_author UNION ALL SELECT id FROM trn_book; 

SELECT id FROM trn_author UNION DISTINCT SELECT id FROM trn_book; 			

SELECT title FROM trn_book WHERE trn_author_id= (SELECT id FROM trn_author WHERE first_name="J.K.Rowling"); 

SELECT * FROM trn_book AS b LEFT JOIN trn_author AS a ON b.trn_author_id=a.id ; 

SELECT * FROM trn_book AS b RIGHT JOIN trn_author AS a ON b.trn_author_id=a.id ;  
SELECT * FROM trn_book AS b CROSS JOIN trn_author AS a ON b.trn_author_id=a.id ; 

SELECT id,title FROM trn_book WHERE title LIKE "%harry%" ;  

SELECT id,title FROM trn_book WHERE title LIKE "_n%" ;
  
SELECT * FROM trn_author GROUP BY first_name; 

SELECT id,first_name,rating FROM trn_author ORDER BY rating DESC;  

SELECT id,first_name,rating FROM trn_author HAVING(rating>4); 
SELECT first_name FROM trn_author WHERE rating>4;  

SELECT * FROM trn_view1;

SELECT title FROM trn_book LEFT JOIN trn_author ON trn_book.trn_author_id = trn_author.id RIGHT JOIN trn_publication ON trn_book.trn_publisher_id= trn_publication.id;

SELECT title FROM trn_book RIGHT JOIN trn_author ON trn_book.trn_author_id = trn_author.id LEFT JOIN trn_publication ON trn_book.trn_publisher_id= trn_publication.id;

SELECT title FROM trn_book LEFT JOIN trn_author ON trn_book.trn_author_id = trn_author.id LEFT JOIN trn_publication ON trn_book.trn_publisher_id= trn_publication.id;

DELETE FROM trn_author WHERE id IN(4,5,7);

SELECT * FROM trn_book WHERE trn_author_id= (SELECT id FROM trn_author WHERE first_name="J.K.Rowling") ORDER BY id;

SELECT title FROM trn_book WHERE quantity > ANY (SELECT id FROM trn_author WHERE rating=3);

SELECT title, MIN(quantity) FROM trn_book GROUP BY trn_author_id HAVING MAX(quantity); 

SELECT * FROM trn_book AS b JOIN trn_author AS a ON b.trn_author_id=a.id JOIN trn_publication AS p ON b.trn_publisher_id=p.id JOIN trn_movie AS m ON b.trn_movie_id=m.id;
SELECT * FROM trn_book AS b LEFT JOIN trn_author AS a ON b.trn_author_id=a.id RIGHT JOIN trn_publication AS p ON b.trn_publisher_id=p.id LEFT JOIN trn_movie AS m ON b.trn_movie_id=m.id;
SELECT * FROM trn_book AS b LEFT JOIN trn_author AS a ON b.trn_author_id=a.id LEFT JOIN trn_publication AS p ON b.trn_publisher_id=p.id LEFT JOIN trn_movie AS m ON b.trn_movie_id=m.id;
SELECT * FROM trn_book AS b RIGHT JOIN trn_author AS a ON b.trn_author_id=a.id LEFT JOIN trn_publication AS p ON b.trn_publisher_id=p.id RIGHT JOIN trn_movie AS m ON b.trn_movie_id=m.id;

SELECT * FROM trn_view2 WHERE id=103;

SELECT id,first_name,MAX(rating) FROM trn_author WHERE id IS NOT NULL;
SELECT id,first_name,MIN(rating) FROM trn_author WHERE id IS NOT NULL;

