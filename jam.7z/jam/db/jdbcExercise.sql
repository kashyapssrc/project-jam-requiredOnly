DROP TABLE person;

DROP TABLE address;

CREATE TABLE address ( `id` BIGINT(20) AUTO_INCREMENT PRIMARY KEY 
                       , `street`  VARCHAR(100) 
                       , `city`    VARCHAR(15)
                       , `pincode` INT(11) NOT NULL
                     );

CREATE TABLE person ( `id` BIGINT(20) AUTO_INCREMENT PRIMARY KEY
                      , `address_id` BIGINT(20)
                      , `first_name` VARCHAR(50)
                      , `last_name` VARCHAR(50)
                      , `email` VARCHAR(100) UNIQUE
                      , `birth_date` DATE
                      , `created_date` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                      , KEY address_id_fk (`address_id`)
                      , CONSTRAINT person_address_fk FOREIGN KEY (address_id) 
                        REFERENCES address (`id`)
                    );

SELECT * FROM address;

SELECT * FROM person;

DELETE FROM address WHERE id = "";