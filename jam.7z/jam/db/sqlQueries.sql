CREATE TABLE author
			(
				  id INT PRIMARY KEY
				, salutation VARCHAR(20)
				, first_name VARCHAR(20)
				);

INSERT INTO author VALUES(1,"Mrs","J.K.Rowling");
INSERT INTO author VALUES(2,"Mr","Chetan");
INSERT INTO author VALUES(3,"Mr","A.P.J.Kalam");

SELECT * FROM author;

ALTER TABLE author ADD(rating INT);

UPDATE author SET rating = 5 WHERE first_name="A.P.J.Kalam";
UPDATE author SET rating = 3 WHERE first_name="J.K.Rowling";
UPDATE author SET rating = 2 WHERE first_name="Chetan";

CREATE TABLE book
			(
				  id INT PRIMARY KEY
				, title VARCHAR(20)
				, quantity INT 
				, author_id INT 
			);
ALTER TABLE book ADD(CONSTRAINT FOREIGN KEY (author_id) REFERENCES author (id) ON DELETE NO ACTION ON UPDATE NO ACTION);

INSERT INTO book VALUES(101,"Two states",1,2);
INSERT INTO book VALUES(102,"India 2020",1,3);
INSERT INTO book VALUES(103,"Harry potter vol 1",1,1);
INSERT INTO book VALUES(104,"Harry potter vol 2",1,1);
INSERT INTO book VALUES(106,"Harry potter vol 3",1,1);
INSERT INTO book VALUES(105,"Harry potter vol 4",1,1);

SELECT * FROM book;			

UPDATE book SET quantity=2 WHERE id=102;

SELECT id FROM author UNION ALL SELECT id FROM book; 

SELECT id FROM author UNION DISTINCT SELECT id FROM book; 			

SELECT title FROM book WHERE author_id= (SELECT id FROM author WHERE first_name="J.K.Rowling"); 

SELECT * FROM book AS b LEFT JOIN author AS a ON b.author_id=a.id ; 

INSERT INTO author VALUES(5,"Mr","Dan Brown",3);
INSERT INTO author VALUES(7,"Mrs","Agatha cristie",3);

SELECT * FROM book AS b RIGHT JOIN author AS a ON b.author_id=a.id ;  
SELECT * FROM book AS b CROSS JOIN author AS a ON b.author_id=a.id ; 

SELECT * FROM book WHERE title LIKE "%harry%" ;  

SELECT * FROM book WHERE title LIKE "_n%" ;
  
SELECT * FROM author GROUP BY first_name; 

SELECT * FROM author ORDER BY rating DESC;  

SELECT * FROM author HAVING(rating>4); 
SELECT first_name FROM author WHERE rating>4;  

CREATE VIEW view1 (author_id,salutation,first_name,rating) AS SELECT * FROM author;
SELECT * FROM view1;

ALTER VIEW view1(id,salutation,first_name,rating) AS SELECT * FROM author;
SELECT * FROM view1;

DROP VIEW view1;

CREATE TABLE publication (id INT PRIMARY KEY
                     ,publisher VARCHAR(25));
					 
INSERT INTO publication VALUES(1,"Penguin");
INSERT INTO publication VALUES(3,"Bloomsbury");
INSERT INTO publication VALUES(2,"Rupa Publications");	

ALTER TABLE book
    ADD publisher_id INTEGER,
    ADD CONSTRAINT FOREIGN KEY(publisher_id) REFERENCES publication(id);

UPDATE book
SET    publisher_id = 
       CASE id
            WHEN 101 THEN 1
            WHEN 102 THEN 2
            WHEN 103 THEN 3
            WHEN 104 THEN 3
            WHEN 105 THEN 3
            WHEN 106 THEN 3    
       END
WHERE  id IN (101,102,103,104,105,106);

SELECT title FROM book LEFT JOIN author ON book.author_id = author.id RIGHT JOIN publication ON book.publisher_id= publication.id;

SELECT title FROM book RIGHT JOIN author ON book.author_id = author.id LEFT JOIN publication ON book.publisher_id= publication.id;

SELECT title FROM book LEFT JOIN author ON book.author_id = author.id LEFT JOIN publication ON book.publisher_id= publication.id;


INSERT INTO author VALUES(8,"Ms","David Kelly",2);
INSERT INTO author VALUES(9,"Mr","George Martin",2);
UPDATE book SET author_id = 8 WHERE id=109;
UPDATE book SET author_id = 9 WHERE id=110;
UPDATE book SET publisher_id = 1 WHERE id=109;
UPDATE book SET publisher_id = 3 WHERE id=110;					 

DELETE FROM author WHERE id IN(4,5,7);

SELECT * FROM book WHERE author_id= (SELECT id FROM author WHERE first_name="J.K.Rowling") ORDER BY id;

SELECT title FROM book WHERE quantity > ANY (SELECT id FROM author WHERE rating=3);

SELECT title, MAX(quantity) FROM book GROUP BY author_id HAVING MAX(quantity); 

CREATE TABLE movie
			(
				  id INT PRIMARY KEY
				, film VARCHAR(20)		
			);
INSERT INTO movie VALUES(1,"two states");
INSERT INTO movie VALUES(2,"Harry Potter Vol 1");
INSERT INTO movie VALUES(3,"Harry Potter Vol 2");
INSERT INTO movie VALUES(4,"Harry Potter Vol 3");
INSERT INTO movie VALUES(5,"Harry Potter Vol 4");

SELECT * FROM movie;

ALTER TABLE book
    ADD movie_id INTEGER,
    ADD CONSTRAINT FOREIGN KEY(movie_id) REFERENCES movie(id);

SELECT * FROM book;  
 
UPDATE book
SET    movie_id = 
       CASE id
            WHEN 101 THEN 1
            WHEN 103 THEN 2
            WHEN 104 THEN 3
            WHEN 105 THEN 4
            WHEN 106 THEN 5    
       END
WHERE  id IN (101,103,104,105,106);

SELECT * FROM book AS b JOIN author AS a ON b.author_id=a.id JOIN publication AS p ON b.publisher_id=p.id JOIN movie AS m ON b.movie_id=m.id;
SELECT * FROM book AS b LEFT JOIN author AS a ON b.author_id=a.id RIGHT JOIN publication AS p ON b.publisher_id=p.id LEFT JOIN movie AS m ON b.movie_id=m.id;
SELECT * FROM book AS b LEFT JOIN author AS a ON b.author_id=a.id LEFT JOIN publication AS p ON b.publisher_id=p.id LEFT JOIN movie AS m ON b.movie_id=m.id;
SELECT * FROM book AS b RIGHT JOIN author AS a ON b.author_id=a.id LEFT JOIN publication AS p ON b.publisher_id=p.id RIGHT JOIN movie AS m ON b.movie_id=m.id;

CREATE VIEW view2
AS
SELECT  b.id id,
        b.title title,
        a.first_name author_name,
        p.publisher publication_name,
        m.film movie_inspired
FROM    book AS b
        INNER JOIN author AS a
            ON b.author_id = a.id
        INNER JOIN publication AS p
            ON b.publisher_id= p.id
        INNER JOIN movie AS m
            ON b.movie_id = m.id;
            
SELECT * FROM view2 WHERE id=105;
SELECT id,first_name,MAX(rating) FROM author WHERE id IS NOT NULL;
SELECT id,first_name,MIN(rating) FROM author WHERE id IS NOT NULL;
