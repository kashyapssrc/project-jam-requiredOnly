DROP TABLE trn_book;
DROP TABLE trn_author;
DROP TABLE trn_movie;
DROP TABLE trn_publication;
DROP VIEW trn_view1;
DROP VIEW trn_view2;