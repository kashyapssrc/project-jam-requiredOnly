var count = 1;
function change() {
    setInterval(function() {
        var elem = document.getElementById("changeText");
        elem.innerHTML = count++;
    }, 1000);
}
