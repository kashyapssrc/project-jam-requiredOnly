function validate() {

    var userName = document.forms["loginForm"]["userName"].value;
    var password = document.forms["loginForm"]["password"].value;

    if(userName == "" && password== "") {
        alert("user name and password cannot be empty");
        return false;
    }

    if (userName == "") {
        alert("please enter a valid user name");
        return false;
    }

    if (password == "") {
        alert("Please enter a valid password");
        return false;
    }
}