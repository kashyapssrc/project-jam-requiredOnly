function loadPersonData() {

    var request = new XMLHttpRequest();
    var READY_STATE_CODE = 4;
    var STATUS_CODE = 200;

    request.open('GET', 'personData.json', true);
    request.send();

    request.onreadystatechange = function() {
        if (this.readyState == READY_STATE_CODE && this.status == STATUS_CODE) {
            var personData = JSON.parse(this.responseText);
            var col = [];
            for (var i = 0; i < personData.length; i++) {
                for (var key in personData[i]) {
                    if (col.indexOf(key) === -1) {
                        col.push(key);
                    }
                }
            }
            // col.push("action");

            var table = document.createElement("table");
            table.id = "table";
            var tr = table.insertRow(-1);
            for (var i = 0; i < col.length; i++) {
                var th = document.createElement("th");
                th.innerHTML = col[i];
                tr.appendChild(th);
            }

            for (var i = 0; i < personData.length; i++) {
                tr = table.insertRow(-1);
                for (var j = 0; j < col.length; j++) {
                    var tabCell = tr.insertCell(-1);
                    tabCell.innerHTML = personData[i][col[j]];
                    // createButton();
                }
            }

            var divContainer = document.getElementById("topSection");
            divContainer.innerHTML = "";
            divContainer.appendChild(table);

            doPopulate(table.rows[1]);
            var lastSelected = table.rows[1];
            doSelect();
        }
    };
}

function doCreateField() {

    var container = document.getElementById("bottomSection");
    while (container.hasChildNodes()) {
        container.removeChild(container.lastChild);
    }

    container.appendChild(document.createTextNode("Id"));
    var input = document.createElement("input");
    input.id = "id";
    input.type = "text";
    container.appendChild(input);
    container.appendChild(document.createElement("br"));

    container.appendChild(document.createTextNode("First Name"));
    var input = document.createElement("input");
    input.id = "firstName";
    input.type = "text";
    container.appendChild(input);
    container.appendChild(document.createElement("br"));

    container.appendChild(document.createTextNode("Last Name"));
    var input = document.createElement("input");
    input.id = "lastName";
    input.type = "text";
    container.appendChild(input);
    container.appendChild(document.createElement("br"));

    container.appendChild(document.createTextNode("E-Mail"));
    var input = document.createElement("input");
    input.id = "email";
    input.type = "text";
    container.appendChild(input);
    container.appendChild(document.createElement("br"));
}

function submitRecord() {

    var personTable = document.getElementById("table");
    var row = personTable.insertRow(personTable.length);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);

    cell1.innerHTML = document.getElementById("id").value;
    cell2.innerHTML = document.getElementById("firstName").value;
    cell3.innerHTML = document.getElementById("lastName").value;
    cell4.innerHTML = document.getElementById("email").value;

    var divContainer = document.getElementById("topSection");
    divContainer.innerHTML = "";
    divContainer.appendChild(personTable);

    document.getElementById("id").value = "";
    document.getElementById("firstName").value = "";
    document.getElementById("lastName").value = "";
    document.getElementById("email").value = "";
}

function doSelect() {

    var resultTable = document.getElementById("table");
    for (var i = 1; i < table.rows.length; i++) {
        resultTable.rows[i].onClick = function () {
            doPopulate(this);
            lastSelected = this;
        };
    }
}

function doPopulate(row) {

    document.getElementById("id").value = row.cells[0].innerHTML;
    document.getElementById("firstName").value = row.cells[1].innerHTML;
    document.getElementById("lastName").value = row.cells[2].innerHTML;
    document.getElementById("email").value = row.cells[3].innerHTML;
}

  function createButton() {
        var button = document.createElement("button");
        button.id = "delete";
        var t = document.createTextNode("delete");
        button.appendChild(t);
        document.getElementById("table").appendChild(button);
    }

function resetToBlank() {
    document.getElementById('id').value = '';
    document.getElementById('firstName').value = '';
    document.getElementById('lastName').value = '';
    document.getElementById('email').value = '';
}

function deleteRow(row) {
    var record = row.parentNode.parentNode.rowIndex;
    document.getElementById("table").deleteRow(record);
}