package com.ofs.training.basics;

public class EnumComparator {

    enum Day {
        SUNDAY,
        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY;
    }

    public boolean checkValueEquality(Day dayOne, Day dayTwo) {
        if (dayOne == null | dayTwo == null){
            throw new RuntimeException("Object cannot be null");
        }

        boolean result = dayOne.equals(dayTwo);
        return result;
    }

    public boolean checkObjectEquality(Day dayOne, Day dayTwo) {
        if (dayOne == null | dayTwo == null){
            throw new RuntimeException("Object cannot be null");
        }

        boolean result = dayOne == dayTwo;
        return result;
    }

    public static void main(String[] args) {

        EnumComparator comparator = new EnumComparator();
        Day dayOne = Day.SUNDAY;
        Day dayTwo = Day.SUNDAY;

        System.out.println(comparator.checkValueEquality(dayOne, dayTwo));
        System.out.println(comparator.checkObjectEquality(dayOne, dayTwo));
    }
}
