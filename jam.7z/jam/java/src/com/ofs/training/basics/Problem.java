package com.ofs.training.basics;

public class Problem {

    // String s;
    static String s;
    static class Inner {

        void testMethod() {
            s = "Set from Inner";
        }
    }
}
