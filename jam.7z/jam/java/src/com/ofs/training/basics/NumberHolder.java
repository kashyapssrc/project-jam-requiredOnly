package com.ofs.training.basics;

public class NumberHolder {

    public int anInt;
    public float aFloat;

    // initialize(int, float) {
    NumberHolder(int integerValue, float floatValue) {

        // return anInt, aFloat;
        anInt = integerValue;
        aFloat = floatValue;
    }

    // static void execute() {
    public static void main(String[] args) {

        // NumberHolder holder = getObject();
        // holder.initialize(int, float);
        NumberHolder holder = new NumberHolder(2, 1.1f);

        // Console console = getConsole();
        // console.print(anInt, aFloat);
        System.out.println("anInt:" + holder.anInt + ", aFloat:" + holder.aFloat);
    }
}
