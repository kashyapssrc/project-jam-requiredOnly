package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.basics.EnumComparator.Day;

@Test
public class EnumComparatorTest {

    EnumComparator comparator;
    Day dayOne;
    Day dayTwo;

    @BeforeClass
    private void initClass() {

        comparator = new EnumComparator();
    }

    @Test(dataProvider = "testCheckValueEquality_positiveDP")
    private void testCheckValueEquality_positive(boolean expectedResult, Day firstDay, Day secondDay) {

        try {

            boolean actualResult = comparator.checkValueEquality(firstDay, secondDay);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e ) {

            Assert.fail("Unexpected exception for the given input. Expected result is " + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testCheckValueEquality_positiveDP() {

        return new Object[][] {
                                { true, Day.SUNDAY, Day.SUNDAY},
                                { false, Day.SUNDAY, Day.MONDAY},
                                { true, Day.MONDAY, Day.MONDAY},
                                { false, Day.MONDAY, Day.TUESDAY}
        };
    }

    @Test(dataProvider = "testCheckValueEquality_negativeDP")
    private void testCheckValueEquality_negative(Day firstDay, Day secondDay) {

        try {

            comparator.checkValueEquality(firstDay, secondDay);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Object cannot be null");
        }
    }

    @DataProvider
    private Object[][] testCheckValueEquality_negativeDP() {

        return new Object[][] {
                                { null, Day.SUNDAY},
                                { Day.SUNDAY, null},
                                { null, Day.MONDAY},
                                { Day.MONDAY, null}
        };
    }

    @Test(dataProvider = "testCheckObjectEquality_positiveDP")
    private void testCheckObjectEquality_positive(boolean expectedResult, Day firstDay, Day secondDay) {

        try {

            boolean actualResult = comparator.checkObjectEquality(firstDay, secondDay);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e ) {

            Assert.fail("Unexpected exception for the given input. Expected result is " + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testCheckObjectEquality_positiveDP() {

        return new Object[][] {
                                { true, Day.TUESDAY, Day.TUESDAY},
                                { false, Day.TUESDAY, Day.WEDNESDAY},
                                { true, Day.THURSDAY, Day.THURSDAY},
                                { false, Day.FRIDAY, Day.SATURDAY}
        };
    }

    @Test(dataProvider = "testCheckObjectEquality_negativeDP")
    private void testCheckObjectEquality_negative(Day firstDay, Day secondDay) {

        try {

            comparator.checkValueEquality(firstDay, secondDay);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Object cannot be null");
        }
    }

    @DataProvider
    private Object[][] testCheckObjectEquality_negativeDP() {

        return new Object[][] {
                              { null, Day.TUESDAY},
                              { Day.WEDNESDAY, null},
                              { null, Day.FRIDAY},
                              { Day.SATURDAY, null}
        };
    }
}
