package com.ofs.training.basics;

public class CharSequenceReverter implements CharSequence {

    private final CharSequence originalSequence;

    // constructor to initialize the object of class CharSequenceReverter
    public CharSequenceReverter(CharSequence originalSequence) {
        this.originalSequence = originalSequence;
    }

    // method to return the length of the character sequence
    @Override
    public int length() {
        return originalSequence.length();
    }

    // method to return the char value at the specified index
    @Override
    public char charAt(int index) {
        return originalSequence.charAt(originalSequence.length() - index - 1);
    }

    // method to return a CharSequence that is a subsequence of this sequence.
    @Override
    public CharSequence subSequence(int start, int end) {

        int originalSequenceEnd = originalSequence.length() - start;
        int originalSequenceStart = originalSequence.length() - end;

        return new CharSequenceReverter(originalSequence.subSequence(originalSequenceStart, originalSequenceEnd));
    }

    // method to return a string containing the characters in this sequence in the same order as this sequence
    @Override
    public String toString() {
        return this.toString();
    }

    public static void main(String[] args) {

        CharSequence reverter = new CharSequenceReverter("Hello World");
        String reversed = new String();

        for (int index = 0; index < reverter.length(); index++) {
            reversed += reverter.charAt(index);
        }

        System.out.format(reversed);
    }
}
