package com.ofs.training.basics;

public class StringBuilderCapacityFinder {

    // static void execute() {
    public static void main(String[] args) {

        StringBuilder builder = new StringBuilder("Able was I ere I saw Elba.");

        // int capacity = builder.getCapacity();
        // print(capacity);
        System.out.println("the initial capacity of the given string builder is: " + builder.capacity());
    }
}
