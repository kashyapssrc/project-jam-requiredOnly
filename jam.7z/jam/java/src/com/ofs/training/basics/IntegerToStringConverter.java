package com.ofs.training.basics;

public class IntegerToStringConverter {

    public static void main(String[] args) {
        System.out.println(Integer.toHexString(65));
    }
}
