package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class IntegerAdderTest {

    IntegerAdder adder;

    @BeforeClass
    private void initClass() {

        adder = new IntegerAdder();
    }

    @Test(dataProvider = "testAddInteger_positiveDP")
    private void testAddInteger_positive(int expectedSum, String[] integerValues) {

        try {

            int actualSum = adder.addInteger(integerValues);
            Assert.assertEquals(actualSum, expectedSum, "Given input " + integerValues);
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input. Expected result is " + expectedSum);
        }
    }

    @DataProvider
    private Object[][] testAddInteger_positiveDP() {

        return new Object[][] {
                                { 10, new String[] { "1","2","3","4"} },
                                { 8, new String[] { "5","3"} },
                                { 15, new String[] { "10","2","3"} }
        };
    }

    @Test(dataProvider = "testAddInteger_negativeDP")
    private void testAddInteger_negative(String[] integerValues) {

        try {

            adder.addInteger(integerValues);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Number of arguments should not be less than two");
        }
    }

    @DataProvider
    private Object[][] testAddInteger_negativeDP() {

        return new Object[][] {
                                {new String[] { "0"} },
                                    {new String[] { "1"} },
                                {new String[] { "2"} },
                                {new String[] { "3"} },
                                {new String[] { "4"} },
                                {new String[] { "5"} },
                                {new String[] { "6"} },
                                {new String[] { "7"} },
                                {new String[] { "8"} },
                                {new String[] { "9"} },
        };
    }
}
