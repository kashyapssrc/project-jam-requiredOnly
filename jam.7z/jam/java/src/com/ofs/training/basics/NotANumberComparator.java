package com.ofs.training.basics;

public class NotANumberComparator {

    public static void main(String[] args) {

        Double number = 1.1;
        Float floatNumber = number.floatValue();
        System.out.println(floatNumber.isNaN());
    }
}
