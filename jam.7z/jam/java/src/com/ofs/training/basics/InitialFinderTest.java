package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class InitialFinderTest {

    InitialFinder finder;

    @BeforeClass
    private void initClass() {

        finder = new InitialFinder();
    }

    @Test(dataProvider = "testFindInitial_positiveDP")
    private void testFindInitial_positive(char expectedInitial, String[] name ) {

        try {

            char actualInitial = finder.findInitial(name);
            Assert.assertEquals(actualInitial, expectedInitial, "Given input " + name);
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input. Expected result is " + expectedInitial);
        }
    }

    @DataProvider
    private Object[][] testFindInitial_positiveDP() {

        return new Object[][] {
                                { 'S', new String[] { "Jayanth","Subramanian"} },
                                { 'V', new String[] { "Rahul","Varma"} },
                                { 'D', new String[] { "Riya","Dutta"} },
                                { 'S', new String[] { "Pradeep","Arjun","Sharma"} }
        };
    }

    @Test(dataProvider = "testFindInitial_negativeDP")
    private void testFindInitial_negative(String[] name) {

        try {

            finder.findInitial(name);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Input cannot have just one string");
        }
    }

    @DataProvider
    private Object[][] testFindInitial_negativeDP() {

        return new Object[][] {
                                { new String[] { "Jayanth"} },
                                { new String[] { "Rahul"} },
        };
    }
}
