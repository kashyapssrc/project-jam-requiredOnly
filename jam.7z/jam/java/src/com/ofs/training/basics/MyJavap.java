package com.ofs.training.basics;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

public class MyJavap {

    public static void main(String[] args) {

        String packageName = args[0];
        // print(package);
        System.out.println(packageName);

        // String[] className = package.spiltIntoSubStrings();
        String[] classNameArray = packageName.split("\\.");
        String className = classNameArray[(classNameArray.length) - 1];

        // print(className);
        System.out.println("Compiled from " + className);

        // className.checkClassExists()
        try {

            // Class myClass = className.getClass();
            Class<?> myClass = Class.forName(packageName);

            // modifier = myClass.getModifiers();
            int modifier = myClass.getModifiers();

            // Class[] interfaces = myClass.getInterfaces();
            Class<?>[] classInterfaces = myClass.getInterfaces();

            // print(modifier, interfaces);
            System.out.println(Modifier.toString(modifier) + " " + myClass + " implements " + classInterfaces[0]);
            for (int index = 1; index < classInterfaces.length; index++){
                System.out.println(", " + classInterfaces[index]);
            }

            // Constructors[] constructors = myClass.getConstructors();
            Constructor<?>[] classConstructors = myClass.getConstructors();

            // print(constructors);
            for (Constructor<?> classConstructor : classConstructors) {
                System.out.println(classConstructor);
            }

            // Fields[] fields = myClass.getFields();
            Field[] classFields = myClass.getFields();

            // print(fields);
            for (Field classField : classFields) {
                System.out.println(classField);
            }

            // Method[] methods = myClass.getMethods();
            Method[] classMethods = myClass.getMethods();

            // print(methods);
            for (Method classMethod : classMethods) {
                    System.out.println(classMethod);
            }
        } catch (ClassNotFoundException exception) {

            // print(error: class not found);
           System.out.println(exception);
        }
    }
}
