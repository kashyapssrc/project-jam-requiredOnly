package com.ofs.training.basics;

public class ExceptionHandler {

    public static void main(String[] args) {

        int a = 3;
        try {
            if (a % 2 == 0) {
                System.out.println("given value is even");
            } else {
                throw new Exception("odd integer");
            }
        } catch (Exception exception) {
            System.out.println("given value is odd");
        }
    }
}
