package com.ofs.training.basics;

import java.util.ArrayList;

public class Employee {

    private static int count = 0;
    private int id;
    private String name;

    Employee(String name) {

        // initialize name of the object
        this.name = name;

        // increment id
        this.id = ++count;
    }

    @Override
    public String toString() {

        // return id, name
        return "ID:" + id + " Name:" + name + "\n";
    }

    public static void main(String[] args) {

        // Employee employee1 = Employee()
        // employee1.display()
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(new Employee("Jayanth"));
        employees.add(new Employee("Praveen"));
        employees.add(new Employee("Dhilip"));
        employees.add(new Employee("Raji"));
        employees.add(new Employee("Pradeep")) ;
        employees.add(new Employee("Sandeep"));
        employees.add(new Employee("Siva"));
        employees.add(new Employee("Hari"));
        employees.add(new Employee("Rahul"));
        employees.add(new Employee("Priya"));

        System.out.println(employees.toString());
    }
}
