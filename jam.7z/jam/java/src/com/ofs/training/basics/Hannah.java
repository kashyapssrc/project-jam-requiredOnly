package com.ofs.training.basics;

public class Hannah {

    public static void main(String[] args) {

        String hannah = "Did Hannah see bees? Hannah did.";
        String car = "Was it a car or a cat I saw?";

        System.out.println("Length of string is " + hannah.length());
        System.out.println("Character at position 12 is " + hannah.charAt(12));
        System.out.println("Character e is at position " + hannah.indexOf('b'));
        System.out.println("Sub string starting at position 9 and ends at 12 is " + car.substring(9, 12));
    }
}
