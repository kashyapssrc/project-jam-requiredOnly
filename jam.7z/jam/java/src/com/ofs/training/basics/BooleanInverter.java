package com.ofs.training.basics;

public class BooleanInverter {

    // static void execute() {
    public static void main(String[] args) {

        int number = 3;
        boolean result = true;

        // boolean result = number.checkEqual();
        if (number == 3) {
            result = true;
        }

        System.out.print(result);

        // boolean invertedResult = negate(result);
        System.out.print(! result);
    }
}
