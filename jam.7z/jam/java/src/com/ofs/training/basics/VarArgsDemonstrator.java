package com.ofs.training.basics;

public class VarArgsDemonstrator {

    void display(String... varArgs) {

        // print varArgs...
        for (String output : varArgs) {
            System.out.println(output);
        }
    }

    // static void execute() {
    public static void main(String[] args) {

        VarArgsDemonstrator demonstrator = new VarArgsDemonstrator();
        String firstString = "Apple";
        String secondString = "Orange";
        demonstrator.display(firstString, secondString);
        String thirdString = "Berry";
        demonstrator.display(thirdString);
    }
}
