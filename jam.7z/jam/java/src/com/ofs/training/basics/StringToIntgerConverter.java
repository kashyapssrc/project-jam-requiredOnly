package com.ofs.training.basics;

public class StringToIntgerConverter {

    public static void main(String[] args) {
        System.out.println(Integer.valueOf("230", 5));
    }
}
