package com.ofs.training.basics;

public class InitialFinder {

    public char findInitial(String[] inputName) {

        if (inputName.length >= 2) {

            String[] name = inputName;
            String surName = name[name.length - 1];
            char initial = surName.charAt(0);
            return initial;
        }
        throw new RuntimeException("Input cannot have just one string");
    }

    public static void main(String[] args) {

        InitialFinder finder = new InitialFinder();
        System.out.println("The initial is: " + finder.findInitial(args));
    }
}
