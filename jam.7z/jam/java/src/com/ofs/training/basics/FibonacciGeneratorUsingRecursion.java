package com.ofs.training.basics;

public class FibonacciGeneratorUsingRecursion {

    static int first = 0;
    static int second = 1;
    static int sum = 0;
    static int count = 10;

    // static void fibonacciRecursion() {
    public void fibonacciRecursion(int count) {

        if (count > 0) {

            sum = first + second;
            first = second;
            second = sum;

            // Console console = getConsole();
            // console.print(sum);
            System.out.println(sum);

            // int next = count - 1;
            // fibonacciRecursion(next);
            fibonacciRecursion(count - 1);
        }
    }

    // static void execute() {
    public static void main(String[] args) {

        // console print(first);
        System.out.println(first);

        // console print(second);
        System.out.println(second);

        // int next = count - 2;
        //fibonacciRecursion(next);
        FibonacciGeneratorUsingRecursion recursion = new FibonacciGeneratorUsingRecursion();
        recursion.fibonacciRecursion((count - 2));
    }
}
