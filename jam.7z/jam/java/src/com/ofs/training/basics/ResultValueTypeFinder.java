package com.ofs.training.basics;

public class ResultValueTypeFinder {

    public static void main(String[] args) {

        ResultValueTypeFinder finder = new ResultValueTypeFinder();
        Object objectOne = 100 / 24;
        System.out.println(finder.getReturnType(objectOne));

        Object objectTwo = 100.10 / 10;
        System.out.println(finder.getReturnType(objectTwo));

        Object objectThree = 'Z' / 2;
        System.out.println(finder.getReturnType(objectThree));

        Object objectFour = 10.5 / 0.5;
        System.out.println(finder.getReturnType(objectFour));

        Object objectFive = 12.4 % 5.5;
        System.out.println(finder.getReturnType(objectFive));

        Object objectSix = 100 % 56;
        System.out.println(finder.getReturnType(objectSix));
    }

    String getReturnType(Object objectValue) {

        if (objectValue != null) {
            if (objectValue instanceof Integer) {
                return "int";
            }

            else if (objectValue instanceof Double) {
                return "double";
            }

            else if (objectValue instanceof Character) {
                return "char";
            }

            else if (objectValue instanceof Float) {
                return "float";
            }

            return null;
        }

        throw new RuntimeException("invalid expression");
    }
}
