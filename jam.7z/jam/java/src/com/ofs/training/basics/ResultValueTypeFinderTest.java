package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class ResultValueTypeFinderTest {

    ResultValueTypeFinder finder;

    @BeforeClass
    private void initClass() {

        finder = new ResultValueTypeFinder();
    }

    @Test(dataProvider = "testGetReturnType_positiveDP")
    private void testGetReturnType_positive1(String expectedResult, Object objectValue) {

        try {

            String actualResult = finder.getReturnType(objectValue);
            Assert.assertEquals(actualResult, expectedResult, "Given input " + objectValue);
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input. Expected result is " + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testGetReturnType_positiveDP() {

        return new Object[][] {
                                { "int", 100 / 24},
                                { "double", 100.10 / 10 },
                                { "int", 'Z' / 2},
                                { "double",10.5 / 0.5},
                                { "double",12.4 % 5.5},
                                { "int", 100 % 56}
        };
    }

    @Test
    private void testGetReturnType_negative() {

        try {

            finder.getReturnType(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "invalid expression");
        }
    }
}
