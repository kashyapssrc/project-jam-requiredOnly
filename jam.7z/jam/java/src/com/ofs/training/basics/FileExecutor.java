package com.ofs.training.basics;

import java.lang.reflect.Method;

public class FileExecutor {

    // static void execute(String className) {
    public static void main(String[] args) throws Exception {

        // checkClassArguments() {
        if(args.length != 1) {

            // print("error:only one class in allowed");
            System.out.println("Only one argument is allowed");
            return;
        }

        String myClassName = args[0];

        // myClassName.checkClassExists()
        try {

            // Class myClass = myClassName.getClass();
            Class<?> myClass = Class.forName(myClassName);

            // Method myMainMethod = getMethod("main");
            String myMethod = "main";
            Method myMainMethod = myClass.getMethod(myMethod, String[].class);
            String[] arguments = null;

            // myMainMethod.checkMethodExists()
            // myMainMethod.execute();
            myMainMethod.invoke(null, (Object) arguments);
        } catch(ClassNotFoundException exception) {

            //print(error:class not found)
            System.out.println(exception);
        } catch(NoSuchMethodException exception) {

            // print(error: method not found)
            System.out.println(exception);
        }
    }
}
