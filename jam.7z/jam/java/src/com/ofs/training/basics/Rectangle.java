package com.ofs.training.basics;

public class Rectangle {

    int width;
    int height;

    int area(int width, int height) {
        int volume = width * height;
        return volume;
    }

    public static void main(String[] args) {

        // Rectangle myRect;
        Rectangle myRect = new Rectangle();
        myRect.width = 40;
        myRect.height = 50;

        // System.out.println("myRect's area is " + myRect.area());
        System.out.println("myRect's area is " + myRect.area(myRect.width, myRect.height));
    }
}
