package com.ofs.training.basics;

public class StringLengthFinder {

    int getSubStringLength(String subString) {

        if (subString.isEmpty()) {
            throw new RuntimeException("Sub string cannot be empty");
        }

        int stringLength = subString.length();
        return stringLength;
    }

    String getSubString(String inputString) {

        if (inputString.isEmpty()){
            throw new RuntimeException("Input string cannot be empty");
        }

        String subString = inputString.substring(9, 12);
        return subString;
    }

    public static void main(String[] args) {


        StringLengthFinder finder = new StringLengthFinder();
        String inputString = "Was it a car or a cat I saw?";

        String subString = finder.getSubString(inputString);
        System.out.format("The sub string is: %s", subString);
        System.out.format("\nThe length of given sub string is: %s", finder.getSubStringLength(subString));
    }
}
