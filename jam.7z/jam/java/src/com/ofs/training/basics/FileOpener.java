package com.ofs.training.basics;

public class FileOpener {

    // static void execute() {
    public static void main(String[] args) throws Exception {

        // ClassFileLocationFinder currentProgram = getCurrentProgram();
        ClassFileLocationFinder currentProgram = new ClassFileLocationFinder();

        // Class currentClass = currentProgram.getClass();
        // String currentClassName = currentClass.getName();
        String currentClassName = currentProgram.getClass().getName();

        // File currentClassFile = currentClass.getFile();
        // String absolutePath = currentClassFile.getAbsolutePath();
        // String absolutePath = currentClass.getProtectionDomain()
        //                                  .getCodeSource()
        //                                  .getLocation()
        //                                  .getFile();
        // Console notepad = getConsole();
        // notepad.open(currentClassFile);
        String[] commandArray = new String[2];
        commandArray[0] = "notepad.exe";
        commandArray[1] = currentClassName + ".java";
        Process process = Runtime.getRuntime().exec(commandArray);
    }
}
