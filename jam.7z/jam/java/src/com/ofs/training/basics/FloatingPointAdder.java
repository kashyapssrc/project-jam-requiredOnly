package com.ofs.training.basics;

public class FloatingPointAdder {

    public float addFloat(String[] floatValues) {
        float sum = (float) 0.0;
        if (floatValues.length < 2) {
            throw new RuntimeException("Number of arguments should not be less than two");
        }

        for (String floatValue : floatValues) {
            float iterator = Float.parseFloat(floatValue);
            sum += iterator;
        }
        return sum;
    }

    public static void main(String... varArgs) {
        FloatingPointAdder adder = new FloatingPointAdder();
        float sum = adder.addFloat(varArgs);
        System.out.println(sum);
    }
}
