package com.ofs.training.basics;

public class StringEqualizer {

    //static void execute() {
    public static void main(String[] args) {

        String firstString = "Computer";
        String secondString = "Computer";

        // boolean result = equals(firstString, secondString);
        boolean result = firstString.equals(secondString);

        // Console console = getConsole();
        // console.print(result);
        System.out.println(result);

        // boolean anotherResult = firstString == secondString;
        boolean anotherResult = firstString == secondString;

        // console.print(anotherResult);
        System.out.println(anotherResult);
    }
}
