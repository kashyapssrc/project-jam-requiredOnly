package com.ofs.training.basics;

import java.util.Arrays;

public class ArraySorter {

    public String[] sortArray(String[] cities) {

        if (cities == null) {
            throw new RuntimeException("Input string array cannot be empty");
        }

        Arrays.sort(cities, String.CASE_INSENSITIVE_ORDER);
        return cities;
    }

    public String[] convertToUpperCase(String[] cities) {

        if (cities == null) {
            throw new RuntimeException("Sorted string array cannot be empty");
        }

        for (int index = 0; index < cities.length; index += 2) {
            cities[index] = cities[index].toUpperCase();
        }
        return cities;
    }

    public static void main(String[] args) {

        String[] cities = { "Chennai",
                            "Pondicherry",
                            "Tiruvannamalai",
                            "Banglore" };

        ArraySorter sorter = new ArraySorter();
        String[] sortedCities = sorter.sortArray(cities);
        for (String city : sortedCities) {
            System.out.format("\n" + city);
        }

        String[] convertedCities = sorter.convertToUpperCase(sortedCities);
        for (String city : convertedCities) {
            System.out.format("\n" + city);
        }
    }
}
