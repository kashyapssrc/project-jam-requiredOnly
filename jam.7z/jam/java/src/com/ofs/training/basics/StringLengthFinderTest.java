package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class StringLengthFinderTest {

    StringLengthFinder finder;

    @BeforeClass
    private void initClass() {

        finder = new StringLengthFinder();
    }

    @Test(dataProvider = "testGetSubString_positiveDP")
    private void testGetSubString_positive(String expectedResult, String inputString) {

        try {

            String actualResult = finder.getSubString(inputString);
            Assert.assertEquals(actualResult, expectedResult, "Given input " + inputString );
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input " + inputString + ". Expected result is " +expectedResult);
        }
    }

    @DataProvider
    private Object[][] testGetSubString_positiveDP() {

        return new Object[][] {
                                { "car", "Was it a car or a cat I saw?" },
                                { "sow", "What you sow is what you reep" }
        };
    }

    @Test
    private void testGetSubString_negative() {

        try {

            finder.getSubString("");
            Assert.fail("Expected an exception.");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "Input string cannot be empty");
        }
    }

    @Test(dataProvider = "testGetSubStringLength_positiveDP")
    private void testGetSubStringLength_positive(int expectedResult, String subString) {

        try {

            int actualResult = finder.getSubStringLength(subString);
            Assert.assertEquals(actualResult, expectedResult, "Given input " + subString );
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input " + subString + ". Expected result is " +expectedResult);
        }
    }

    @DataProvider
    private Object[][] testGetSubStringLength_positiveDP() {

        return new Object[][] {
                                { 3, "car" },
                                { 3, "sow" }
        };
    }

    @Test
    private void testGetSubStringLength_negative() {

        try {

            finder.getSubStringLength("");
            Assert.fail("Expected an exception.");
        } catch (Exception e) {

            Assert.assertEquals(e.getMessage(), "Sub string cannot be empty");
        }
    }
}
