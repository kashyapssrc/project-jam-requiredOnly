package com.ofs.training.basics;

public class FibonacciGeneratorUsingWhile {

    // static void execute() {
    public static void main(String[] args) {

        int count = 10;
        int first = 0;
        int second = 1;

        // Console console = getConsole();
        // console.print(count);
        System.out.format("Fibonacci Series of %d numbers is ", count);
        int iterator = 1;
        while (iterator <= count) {

            // console.print(first);
            System.out.format("%d ", first);

            int sum = first + second;
            first = second;
            second = sum;

            //increment iterator
            iterator++;
        }
    }
}
