package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class ArraySorterTest {

    ArraySorter sorter;

    @BeforeClass
    private void initClass() {

        sorter = new ArraySorter();
    }

    @Test (dataProvider = "testSortArray_positiveDP")
    private void testSortArray_positive(String[] expectedResult, String[] inputArray) {

        try {

            String[] actualResult = sorter.sortArray(inputArray);
            Assert.assertEquals(actualResult, expectedResult, "Given input " + inputArray);
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input. Expected result is " + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testSortArray_positiveDP() {

        return new Object[][] {
                                { new String[] {"Erode",
                                                "Karur",
                                                "Madurai",
                                                "Salem",
                                                "Thanjavur",
                                                "TRICHY",
                                                "trichy"},
                                 new String[] { "Madurai",
                                                "Thanjavur",
                                                "TRICHY",
                                                "Karur",
                                                "Erode",
                                                "trichy",
                                                "Salem" } },
                                 {new String[] {"Banglore",
                                                "Chennai",
                                                "Pondicherry",
                                                "Tiruvannamalai" },
                                  new String[] {"Chennai",
                                                "Pondicherry",
                                                "Tiruvannamalai",
                                                "Banglore"}
                                }
        };
    }

    @Test
    private void testSortArray_negative() {

        try {

            sorter.sortArray(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Input string array cannot be empty");
        }
    }

    @Test(dataProvider = "testConvertToUpperCase_positiveDP")
    private void testConvertToUpperCase_positive(String[] inputArray, String[] expectedResult) {

        try {

            String[] actualResult = sorter.convertToUpperCase(inputArray);
            Assert.assertEquals(actualResult, expectedResult, "Given input " + inputArray);
        } catch (Exception e) {

            throw new RuntimeException("Unexpected exception for the given input. Expected result is " + expectedResult);
        }
    }

    @DataProvider
    private Object[][] testConvertToUpperCase_positiveDP() {

        return new Object[][] {
                                { new String[] {"Erode",
                                                "Karur",
                                                "Madurai",
                                                "Salem",
                                                "Thanjavur",
                                                "TRICHY",
                                                "trichy"},
                                  new String[] {"ERODE",
                                                "Karur",
                                                "MADURAI",
                                                "Salem",
                                                "THANJAVUR",
                                                "TRICHY",
                                                "TRICHY"} },
                                { new String[] {"Chennai",
                                                "Pondicherry",
                                                "Tiruvannamalai",
                                                "Banglore"},
                                  new String[] {"CHENNAI",
                                               "Pondicherry",
                                               "TIRUVANNAMALAI",
                                               "Banglore"}
                                }
        };
    }

    @Test
    private void testConvertToUpperCase_negative() {

        try {

            sorter.sortArray(null);
            Assert.fail("Expected an exception.");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Input string array cannot be empty");
        }
    }
}
