package com.ofs.training.basics;

public class IntegerAdder {

    public int addInteger(String[] integerValues) {

        int sum = 0;
        if (integerValues.length < 2) {
            throw new RuntimeException("Number of arguments should not be less than two");
        }

        for (String integerValue : integerValues) {
            int iterator = Integer.parseInt(integerValue);
            sum += iterator;
        }
        return sum;
    }

    public static void main(String... varArgs) {

        IntegerAdder adder = new IntegerAdder();
        String[] arguments = varArgs;

        System.out.println(adder.addInteger(arguments));
    }
}
