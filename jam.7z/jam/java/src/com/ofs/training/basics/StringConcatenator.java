package com.ofs.training.basics;

public class StringConcatenator {

    // static void execute() {
    public static void main(String[] args) {

        String hi = "Hi, ";
        String mom = "mom.";

        // String concatenatedString = concatenate(hi, mom);
        String concatenatedString = hi.concat(mom);

        // print(concatenatedString);
        System.out.println(concatenatedString);

        // String resultString = hi + mom;
        String resultString = hi + mom;

        // print(resultString);
        System.out.println(resultString);
    }
}
