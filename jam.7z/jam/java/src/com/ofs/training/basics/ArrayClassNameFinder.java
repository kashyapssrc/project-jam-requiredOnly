package com.ofs.training.basics;

public class ArrayClassNameFinder {

    // static void execute() {
    public static void main(String[] args) {

        int[] integers       = {1, 2, 3};
        char[] characters     = {'a', 'b', 'c'};
        String[] strings = {"one", "two", "three"};

        // Class intClass    = intArray.getClass();
        // String intClassName = intClass.getName();
        // Console console = getConsole();
        // console.print(intClassName);
        System.out.format(integers.getClass().getName());

        // Class charClass   = charArray.getClass();
        // String charClassName = charClass.getName();
        // console.print(charClassName);
        System.out.format("\n" + characters.getClass().getName());

        // Class stringClass = stringArray.getClass();
        // String stringClassName = stringClass.getName();
        // console.print(stringClassName);
        System.out.format("\n" + strings.getClass().getName());
    }
}
