package com.objectfrontier.training.io;

import java.io.File;

public class FilePermissionDisplay {

    public static void main(String[] args) {
        FilePermissionDisplay display = new FilePermissionDisplay();
        File file = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
        display.showFilePermission(file);
    }

    private void showFilePermission(File file) {
        if (file.exists()) {
            System.out.format("Executable: %s%n", file.canExecute()); 
            System.out.format("Readable: %s%n", file.canRead()); 
            System.out.format("Writable: %s%n", file.canWrite()); 
        } else { 
            System.out.println("Given file is not found."); 
        }
    }
}
