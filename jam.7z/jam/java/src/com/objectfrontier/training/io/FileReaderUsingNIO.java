package com.objectfrontier.training.io;

import java.io.File;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileReaderUsingNIO {

    public static void main(String[] args) throws Exception {
        FileReaderUsingNIO reader = new FileReaderUsingNIO();
        File file = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
        String fileContent = reader.readFile(file.toURI());
        System.out.println(fileContent);
    }

    private String readFile(URI uri) throws Exception {
        String data = ""; 
        data = new String(Files.readAllBytes(Paths.get(uri))); 
        return data; 
    }
}
