package com.objectfrontier.training.io;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class OutputContentWriter {

    public static void main(String[] args) throws Exception {
        OutputContentWriter contentWriter = new OutputContentWriter();
        String greeting = "Welcome";
        contentWriter.writeToFileUsingWriter(greeting);
    }

    private void writeToFileUsingWriter(String greeting) throws IOException {
        Writer writer= new FileWriter("D:/dev/training/jayanth.subramanian/wbs/content.txt");
        try {
            writer.write(greeting);
        } catch (Exception exception) {
            exception.printStackTrace();
        } 
        writer.close();
    }
}
