package com.objectfrontier.training.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class FileContentBufferedReader {

    public static void main(String[] args) {
        String content = null;
        try {
            File fileToRead = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
           BufferedReader bufferedReader = new BufferedReader(new FileReader(fileToRead));
           while ((content = bufferedReader.readLine()) != null) {
              System.out.println(content);
           }
           bufferedReader.close();
        } catch(Exception exception) {
           exception.printStackTrace();
        }
    }
}
