package com.objectfrontier.training.io;

import java.io.File;
import java.io.FileReader;

public class FileContentReader {

    private void readFileContent(File fileToRead) throws Exception {
        FileReader fileReader = new FileReader(fileToRead); 
        char[] cbuf = {};
        int data = fileReader.read(cbuf, 0, (int)fileToRead.length());
        for (int index = 0; index < cbuf.length; index++) {
            System.out.print((char) data);
        }
        fileReader.close();
    }

    public static void main(String[] args) {
        File fileToRead = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
        FileContentReader reader = new FileContentReader();
        try {
            reader.readFileContent(fileToRead);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
}
