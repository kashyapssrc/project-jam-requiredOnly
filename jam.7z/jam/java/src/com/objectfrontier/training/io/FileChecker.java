package com.objectfrontier.training.io;

import java.io.File;

public class FileChecker {

    private void checkWhetherFileOrDirectory(File file) {
        if (file.isDirectory()) {
            System.out.format( "%s is a directory\n", file.getAbsolutePath());
        }
        else if (file.isFile()) {
            System.out.format( "%s is a file\n", file.getAbsolutePath());
        }
    }

    public static void main(String[] args) {
        FileChecker checker = new FileChecker();
        File file = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
        checker.checkWhetherFileOrDirectory(file);
    }
}
