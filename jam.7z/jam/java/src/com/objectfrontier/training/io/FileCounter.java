package com.objectfrontier.training.io;

import java.io.File;

public class FileCounter {

    public static void main(String[] args) {
        FileCounter counter = new FileCounter();
        File file = new File("D:/dev/training/jayanth.subramanian/wbs");
        int countUsingIO = counter.getCountOfFileUsingIO(file);
        System.out.println(countUsingIO);
    }

    private int getCountOfFileUsingIO(File directory) {
            return directory.listFiles().length;
    }
}