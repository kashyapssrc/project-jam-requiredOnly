package com.objectfrontier.training.io;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class SamePathChecker {
    public static void main(String[] args) {
      Path wbsPath = Paths.get("D:\\tools\\eclipse\\eclipse-jee-photon\\eclipse\\eclipse.exe");
      Path path = Paths.get("D:\\path\\ecm.lnk");
      checkSamePath(path, wbsPath);
    }
    private static void checkSamePath(Path path, Path anotherPath) {
      try {
         int isSamePath = path.compareTo(anotherPath);
         System.out.format("isSameFile:%s %n", isSamePath);
        if (Files.isSameFile(path, anotherPath)) {
          System.out.println("Both paths represent same file");
        } else {
          System.out.println("paths are distinct");
        }
      } catch (Exception exception) {
        exception.printStackTrace();
      }
    }
  }
