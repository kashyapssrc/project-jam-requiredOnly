package com.objectfrontier.training.io;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;


public class InputStreamStringConverter {

    public static void main(String[] args) throws Exception {
        InputStreamStringConverter converter = new InputStreamStringConverter();
        InputStream inputStream = new FileInputStream("D:/dev/training/jayanth.subramanian/wbs/content.txt");
        String greeting = converter.convertToString(inputStream);
        System.out.println(greeting);
        InputStream stream = converter.convertToInputStream(greeting);
        System.out.println(stream.toString());
    }

    private InputStream convertToInputStream(String greeting) throws Exception {
        InputStream stream = new ByteArrayInputStream(greeting.getBytes());
        BufferedReader br = new BufferedReader(new InputStreamReader(stream));
        String line;
        while ((line = br.readLine()) != null) {
            System.out.println(line);
        }
        br.close();
        return stream;
    }

    private String convertToString(InputStream stream) throws Exception {
        int content;
        StringBuilder sb = new StringBuilder();
        while((content = stream.read()) != -1) {
            sb.append((char)content);
        }
        return sb.toString();
    }
}
