package com.objectfrontier.training.io;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class OutputStreamContentWriter {

    public static void main(String[] args) throws Exception {
        OutputStreamContentWriter writer = new OutputStreamContentWriter();
        String greeting = "Hello";
        writer.writeToOutputStream(greeting);
    }

    private void writeToOutputStream(String greeting) throws IOException {
        OutputStream stream = new FileOutputStream("D:/dev/training/jayanth.subramanian/wbs/content.txt");
        try {
            stream.write(greeting.getBytes());
        } catch (Exception exception) {
            exception.printStackTrace();
        } 
        stream.close();
    }
}
