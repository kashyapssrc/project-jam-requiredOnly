package com.objectfrontier.training.io;

import java.io.File;
import java.io.FileInputStream;

public class FileInputStreamReader {

    public static void main(String[] args) throws Exception {

        File fileToRead = new File("D:/dev/training/jayanth.subramanian/wbs/shoppingCart.txt");
        FileInputStream inputStream = new FileInputStream(fileToRead);

        try {
            int fileContent;
            while ((fileContent = inputStream.read()) != -1) {
                System.out.print((char) fileContent);
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        } 

        if (inputStream != null) {
            inputStream.close();
        }
    }
}