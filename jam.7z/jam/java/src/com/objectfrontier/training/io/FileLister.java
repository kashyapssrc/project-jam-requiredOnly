package com.objectfrontier.training.io;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class FileLister {

    public static void main(String[] args) {
        FileLister lister = new FileLister();
        File directory = new File("D:/dev/training/jayanth.subramanian/wbs");
        String extension = ".txt";
        List<String> files = lister.listAllFilesWithExtension(directory, extension);

        for (String file : files) {
            System.out.println(file);
        }
    }

    private List<String> listAllFilesWithExtension(File directory, String extension) {
        List<String> fileNames = new ArrayList<>();

        for (File file : directory.listFiles()) {
            if (file.getName().endsWith((extension))) {
                fileNames.add(file.getName());
            }
        }
        return fileNames;
    }
}
