package com.objectfrontier.training.annotations;

import java.lang.reflect.Method;

public class EmployeeDetailsDemo {

    @EmployeeDetailAnnotation(batch = 1,
                              id = 1713,
                              mail = "jayanth.subramanian@object-frontier.com",
                              name = "Jayanth"
                              )
    public void getEmployeeDetails() {

        EmployeeDetailsDemo demo = new EmployeeDetailsDemo();
        try {

            Class<? extends EmployeeDetailsDemo> annotatedClass = demo.getClass();
            Method annotatedMethod = annotatedClass.getMethod("getEmployeeDetails");
            EmployeeDetailAnnotation customAnnotation = annotatedMethod.getAnnotation(EmployeeDetailAnnotation.class);
            System.out.println(customAnnotation.name());
            System.out.println(customAnnotation.id());
            System.out.println(customAnnotation.batch());
            System.out.println(customAnnotation.mail());
        } catch (Exception e) {

            throw new RuntimeException("Invalid elements in the annotation");
        }
    }

    public static void main(String[] args) {

        EmployeeDetailsDemo demo = new EmployeeDetailsDemo();
        demo.getEmployeeDetails();
    }
}
