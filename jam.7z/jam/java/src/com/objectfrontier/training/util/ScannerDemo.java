package com.objectfrontier.training.util;

import java.util.Scanner;

public class ScannerDemo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter any data:");
        String input = scanner.next();
        System.out.println("The data is " + input);
        scanner.close();
   }
}

