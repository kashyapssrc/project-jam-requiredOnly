package com.objectfrontier.training.util;

import java.util.UUID;

public class UniqueIDGenerator {

    public static void main(String[] args) {
        UniqueIDGenerator generator = new UniqueIDGenerator();
        String uuid = generator.generateUniqueId();
        System.out.println(uuid);
    }

    private String generateUniqueId() {
        return UUID.randomUUID().toString();
    }
}
