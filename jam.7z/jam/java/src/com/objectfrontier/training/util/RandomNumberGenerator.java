package com.objectfrontier.training.util;

import java.util.Random;

public class RandomNumberGenerator {

    public static void main(String[] args) {
        Random randomInteger = new Random();
        int randomNumber = randomInteger.nextInt();
        System.out.println(randomNumber);
    }
}
