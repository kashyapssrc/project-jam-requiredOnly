package com.objectfrontier.training.util;

import java.util.Objects;

public class ObjectNotNullChecker {

    public static void main(String[] args) {
        ObjectNotNullChecker checker = new ObjectNotNullChecker();
        Object obj = null;
        boolean isNotNull = checker.checkWhetherNotNull(obj);
        System.out.println(isNotNull);
    }

    private boolean checkWhetherNotNull(Object obj) {
        return Objects.nonNull(obj);
    }
}
