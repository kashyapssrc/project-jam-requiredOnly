package com.objectfrontier.training.util;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class StringEncoderDecoder {

    public static void main(String[] args) throws Exception {
        StringEncoderDecoder coder = new StringEncoderDecoder();
        String password = "Password@123";
        String encodedData = coder.encode(password);
        System.out.println(encodedData);
        byte[] decodedData = coder.decode(encodedData);
        System.out.println(decodedData);
    }

    private byte[] decode(String encodedData) throws Exception {
        BASE64Decoder decoder = new BASE64Decoder();
        return decoder.decodeBuffer(encodedData);
    }

    private String encode(String password) {
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(password.getBytes());
    }
}
