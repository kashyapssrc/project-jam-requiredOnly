package com.objectfrontier.training.util;

import java.time.chrono.IsoChronology;
import java.util.Comparator;

import com.objectfrontier.training.collections.Person;

public class PersonComparator {

    public static void main(String[] args) {
        Person bob = new Person("Bob",
                                IsoChronology.INSTANCE.date(2000, 9, 12),
                                Person.Sex.MALE,
                                "bob@example.com");
        Person anotherBob = new Person("Bob",
                                        IsoChronology.INSTANCE.date(2000, 9, 12),
                                        Person.Sex.MALE,
                                        "bob@example.com");
        Comparator<Person> comparator = (personOne, personTwo) -> {
            if (personOne.equals(personTwo)) {
                return 1;
            }
            return 0;
        };
        int result = comparator.compare(bob, anotherBob);
        System.out.println(result);

        Comparable<Person> comparable = person -> {
            if (person.equals("")) {
                return 1;
            }
            return 0;
        };
        int anotherResult = comparable.compareTo(anotherBob);
        System.out.println(anotherResult);
    }
}
