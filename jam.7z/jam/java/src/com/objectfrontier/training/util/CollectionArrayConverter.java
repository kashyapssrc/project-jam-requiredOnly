package com.objectfrontier.training.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CollectionArrayConverter {

    public static void main(String[] args) {
        CollectionArrayConverter converter = new CollectionArrayConverter();
        List<Integer> numberList = new ArrayList<>();
        numberList.add(1);
        numberList.add(3);
        numberList.add(2);
        Object[] numbers = converter.convertToArray(numberList);

        for (Object number : numbers) {
            System.out.println(number);
        }

        List<Object> convertedNumberList = converter.convertToList(numbers);
        System.out.println(convertedNumberList);
    }

    private List<Object> convertToList(Object[] numbers) {
        return  Arrays.asList(numbers);
    }

    private Object[] convertToArray(List<Integer> numberList) {
        return numberList.toArray();
    }
}
