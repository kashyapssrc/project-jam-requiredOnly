package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class AddressServiceTest {

    AddressService addressService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/jayanth_subramanian?useSSL=false&user=jayanth_subramanian&password=demo");

    @BeforeClass
    private void initialize() {
        addressService = new AddressService();
    }

//    positive test case to insert a record
    @Test(dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Address address, long expectedResult) throws SQLException {

        try{
            long actualResult = addressService.create(address, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
                Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
                conn.rollback();
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 600235), 1}
        };
    }

//    negative test case to insert a record
    @Test(dataProvider = "testCreate_negativeDP")
    private void testCreate_negative(Address address) {

        try{
            addressService.create(address,conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Pincode cannot be null"
                    + "");
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {

        return new Object[][] {
            {new Address ("Mint street", "Madras", 0)}
        };
    }

//    positive case to update a record
    @Test(dataProvider = "testUpdate_positiveDP")
    private void testUpdate_positive(long id, int expectedResult) {

        try {
            int actualResult = addressService.update(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() throws SQLException {

        return new Object[][] {
            {1, 1},
            {2, 0}
        };
    }

//    negative case to update a record
    @Test
    private void testUpdate_negative() {

        try {
            addressService.update(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot update without id");
        }
    }

//    positive case to read a record using id
    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(long id, Address expectedResult) {

        try {
            Address actualResult = addressService.read(id, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {

        return new Object[][] {
            {1, new Address("Mint street","Madras",600235)}
        };
    }

//    negative case to read a record using id
    @Test
    private void testRead_negative() {

        try {
            addressService.read(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be empty");
        }
    }

//  positive case to read all record using id
    @Test(dataProvider = "testReadAll_positiveDP")
    private void testReadAll_positive(List<Address> expectedResult) {

      try {
          List<Address> actualResult = addressService.readAll(conn);
          Assert.assertEquals(actualResult.toString(), expectedResult.toString());
          conn.commit();
      } catch (Exception e) {
          Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
      }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Address> inputAddress = new ArrayList<>();
        inputAddress.add(new Address("Mint street", "Madras",600235));
      return new Object[][] {
          {inputAddress}
      };
    }

//  negative case to read all record using id
    @Test
    private void testReadAll_negative() {

        try {
            addressService.readAll(null);
            Assert.fail("Expected an exception.");
            conn.rollback();
      } catch (Exception e) {
          Assert.assertEquals(e.getMessage(), "Service not available");
      }
    }

//    positive case to delete a record
    @Test(dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(long id, long expectedResult) {

        try {
            long actualResult = addressService.delete(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() throws SQLException{
        return new Object[][] {
            {2, 2}
        };
    }

//    negative case to delete a record
    @Test
    private void testDelete_negative() {

        try {
            addressService.delete(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Id cannot be null");
        }
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }

}
