package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PersonService {

    AddressService addressService = new AddressService();
    AddressServiceTest addressServiceTest = new AddressServiceTest();

    public int create(Address address, Person person, Connection con) throws Exception {

        int generatedKey = 0;
        try {
            String selectQuery = "SELECT email FROM person";
            PreparedStatement stmt = con.prepareStatement(selectQuery);
            stmt.executeQuery(selectQuery);

            StringBuilder sb = new StringBuilder();
            sb.append("INSERT INTO person (name, email, birth_date, address_id) ");
            sb.append("VALUES (?, ?, ?, ?)");

            PreparedStatement statement = con.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, person.name);
            statement.setString(2, person.email);
            statement.setDate(3, person.birthDate);
            int addressId = addressService.create(address, con);
            statement.setInt(4, addressId);
            statement.executeUpdate();
            ResultSet generatedKeys = statement.getGeneratedKeys();
            if ((generatedKeys != null) && (generatedKeys.next())) {
                generatedKey = generatedKeys.getInt(1);
            }
        } catch (Exception e) {
            throw new RuntimeException("Email already exists");
        }
        return generatedKey;
    }

    public int update(long id, Connection conn) throws SQLException {

        String query;
        int rowsUpdated = 0;

        if (id == 0) {
            throw new RuntimeException("Cannot update without condition");
        }
            query = "UPDATE person SET name = 'praveen' WHERE id = " + id;
            PreparedStatement statement = conn.prepareStatement(query);
            rowsUpdated = statement.executeUpdate();
        return rowsUpdated;
    }

    public Person read(long id, boolean includeAddress, Connection conn) {

        Person person = new Person();

        try {

                String query = "SELECT id, name, email, birth_date, created_date, address_id FROM person WHERE id = "+ id;
                String joinQuery = "SELECT id, name, email, birth_date, created_date, address_id FROM person JOIN address ON address.id = person.address_id WHERE id = "+ id;
                Address address = new Address();

                if (includeAddress) {

                     PreparedStatement statement = conn.prepareStatement(joinQuery);
                     ResultSet result = statement.executeQuery();
                     result.next();
                     address.setId(result.getLong("id"));
                     address.setStreet(result.getString("street"));
                     address.setCity(result.getString("city"));
                     address.setPincode(result.getInt("pincode"));
                     person.setId(result.getLong("id"));
                     person.setAddressId(result.getLong("address_id"));
                     person.setName(result.getString("name"));
                     person.setEmail(result.getString("email"));
                     person.setBirthDate(result.getDate("birth_date"));
                     person.setCreatedDate(result.getTime("created_date"));

                } else {

                    PreparedStatement statement = conn.prepareStatement(query);
                    ResultSet result = statement.executeQuery();
                    result.next();
                    person.setId(result.getLong("id"));
                    person.setAddressId(result.getLong("address_id"));
                    person.setName(result.getString("name"));
                    person.setEmail(result.getString("email"));
                    person.setBirthDate(result.getDate("birth_date"));
                    person.setCreatedDate(result.getTime("created_date"));

                }
        } catch (Exception exception) {
            throw new RuntimeException("ID cannot be empty");
        }
        return person;
    }

    public List<Object> readAll(boolean includeAddress, Connection conn) {

        List<Object> resultRecords = new ArrayList<>();
        Address address = new Address();
        Person person = new Person();

        try {

            String query = "SELECT id, name, email, birth_date, created_date, address_id FROM person";
            String joinQuery = "SELECT id, name, email, birth_date, created_date, address_id FROM person JOIN address ON address.id = person.address_id";
            if (includeAddress) {

                PreparedStatement statement = conn.prepareStatement(joinQuery);
                ResultSet result = statement.executeQuery();
                while (result.next()) {
                    address.setId(result.getLong("id"));
                    address.setStreet(result.getString("street"));
                    address.setCity(result.getString("city"));
                    address.setPincode(result.getInt("pincode"));
                    person.setId(result.getLong("id"));
                    person.setAddressId(result.getLong("address_id"));
                    person.setName(result.getString("name"));
                    person.setEmail(result.getString("email"));
                    person.setBirthDate(result.getDate("birth_date"));
                    person.setCreatedDate(result.getTime("created_date"));
                    resultRecords.add(address);
                    resultRecords.add(person);
                }
            } else {

                PreparedStatement statement = conn.prepareStatement(query);
                ResultSet result = statement.executeQuery();
                while (result.next()) {

                    person.setId(result.getLong("id"));
                    person.setAddressId(result.getLong("address_id"));
                    person.setName(result.getString("name"));
                    person.setEmail(result.getString("email"));
                    person.setBirthDate(result.getDate("birth_date"));
                    person.setCreatedDate(result.getTime("created_date"));
                    resultRecords.add(person);
                }
            }
        } catch (Exception exception) {
            throw new RuntimeException("Service not available");
        }
        return resultRecords;
    }

    public int delete(long id, Connection conn) throws SQLException {

        int rowsDeleted = 0;

        if (id == 0) {
            throw new RuntimeException("Cannot delete without id");
        }
        String query = "DELETE FROM person WHERE address_id = " + id;
        PreparedStatement statement = conn.prepareStatement(query);
        rowsDeleted = statement.executeUpdate();
        return rowsDeleted;
    }
}
