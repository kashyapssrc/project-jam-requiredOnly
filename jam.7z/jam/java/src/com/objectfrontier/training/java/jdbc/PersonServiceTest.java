package com.objectfrontier.training.java.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class PersonServiceTest {

    PersonService personService;
    ConnectionManager txn = new ConnectionManager();
    Connection conn = txn.openConnection("jdbc:mysql://pc1620:3306/jayanth_subramanian?useSSL=false&user=jayanth_subramanian&password=demo");

    @BeforeClass
    private void initialize() {
        personService = new PersonService();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 0)
    private void testCreate_positive(Address address, Person person, int expectedResult) {

        try {
            int actualResult = personService.create(address, person, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() throws ParseException {
        return new Object[][] {
                                { new Address ("Mint street", "Chennai", 600345), new Person ("agi", "agi@gmail.com", Date.valueOf("1996-08-08")), 1},
                                { new Address ("Car street", "Tiruvannamalai", 606601), new Person ("jayanth", "jay@gmail.com", Date.valueOf("1996-08-09")), 2}
        };
    }

    @Test(dataProvider = "testCreate_negativeDP", priority = 1)
    private void testCreate_negative( Address address, Person person) throws Exception {

        try {
            personService.create( address, person, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Email already exists");
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() throws ParseException {
        return new Object[][] {
                                { new Address ("Car street", "Tiruvannamalai", 606601), new Person ("santhosh", "agi@gmail.com", Date.valueOf("1996-02-08"))}
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 2)
    private void testUpdate_positive(long id, int expectedResult) {

        try {
            int actualResult = personService.update(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        return new Object[][] {
                                {1, 1}
                              };
    }

    @Test(priority = 3)
    private void testUpdate_negative() {

        try {

            personService.update(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot update without condition");
        }
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 4)
    private void testRead_positive(long id, boolean includeAddress, Person expectedResult) {

        try {
            Person actualResult = personService.read(id, includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        return new Object[][] {
            {1, false, new Person("praveen","agi@gmail.com",Date.valueOf("1996-08-08"))},
            {2, false, new Person("jayanth","jay@gmail.com",Date.valueOf("1996-08-09"))}
        };
    }

    @Test(priority = 5)
    private void testRead_negative() {

        try {
            personService.read(0, true, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "ID cannot be empty");
        }
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 6)
    private void testReadAll_positive(boolean includeAddress, Object expectedResult) {

        try {
            List<Object> actualResult = personService.readAll(includeAddress, conn);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {
        List<Object> outputResult = new ArrayList<>();
        Person person = new Person("jayanth","jay@gmail.com",Date.valueOf("1996-08-09"));
        outputResult.add(new Person("jayanth","jay@gmail.com",Date.valueOf("1996-08-09")));
        outputResult.add(person);
        return new Object[][] {
            {false, outputResult}
        };
    }

    @Test(priority = 7)
    private void testReadAll_negative() {

        try {
            personService.readAll(false, null);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Service not available");
        }
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 8)
    private void testDelete_positive(long id, int expectedResult) {

        try {
            long actualResult = personService.delete(id, conn);
            Assert.assertEquals(actualResult, expectedResult);
            conn.commit();
        } catch (Exception e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e);
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        return new Object[][] {
            {1, 1}
        };
    }

    @Test(priority = 9)
    private void testDelete_negative() {

        try {
            personService.delete(0, conn);
            Assert.fail("Expected an exception.");
            conn.rollback();
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "Cannot delete without id");
        }
    }

    @AfterClass
    private void closeConnection() {
        txn.closeConnection();
    }
}
