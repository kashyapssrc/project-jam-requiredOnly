
package com.objectfrontier.training.date;

import java.sql.Timestamp;
import java.util.Date;

public class CurrentTimeStampPrinter {

    public static void main(String[] args) {
        CurrentTimeStampPrinter timeStampPrinter = new CurrentTimeStampPrinter();
        Date today = new Date();
        Timestamp current = timeStampPrinter.printCurrentTimeStamp(today);
        System.out.println(current);
    }

    private Timestamp printCurrentTimeStamp(Date today) {
        long currentTime = today.getTime();
        Timestamp current = new Timestamp(currentTime);
        return current;
    }
}
