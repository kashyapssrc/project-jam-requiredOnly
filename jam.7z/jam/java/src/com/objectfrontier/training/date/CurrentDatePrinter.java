package com.objectfrontier.training.date;

import java.time.LocalDateTime;

public class CurrentDatePrinter {

    public static void main(String[] args) {
        CurrentDatePrinter datePrinter = new CurrentDatePrinter();
        datePrinter.printComponentsOfCurrentDate();
    }

    private void printComponentsOfCurrentDate() {
        LocalDateTime currentTime = LocalDateTime.now();
        int dayOfTheMonth = currentTime.getDayOfMonth();
        int monthOfTheYear = currentTime.getMonthValue();
        int currentYear = currentTime.getYear();
        int currentHour = currentTime.getHour();
        int currentMinute = currentTime.getMinute();
        int currentSecond = currentTime.getSecond();
        System.out.format("%d/%d/%d %d:%d:%d ", dayOfTheMonth, monthOfTheYear, currentYear, currentHour, currentMinute, currentSecond);
    }
}
