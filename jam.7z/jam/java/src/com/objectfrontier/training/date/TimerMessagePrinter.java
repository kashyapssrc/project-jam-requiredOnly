package com.objectfrontier.training.date;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

public class TimerMessagePrinter extends TimerTask{

    public static void main(String[] args) {
        Timer timer = new Timer();
        TimerTask task = new TimerMessagePrinter();
        timer.schedule(task, 100, 10000);
    }

    @Override
    public void run() {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm a EEEEE, dd MMMMM yyyy :");
        System.out.println(formatter.format(Calendar.getInstance().getTime()));
        System.out.println("Hi I am auto runner");
    }
}
