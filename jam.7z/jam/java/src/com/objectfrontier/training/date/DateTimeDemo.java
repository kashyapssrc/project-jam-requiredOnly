package com.objectfrontier.training.date;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class DateTimeDemo {

    public static void main(String[] args) {

        DateTimeDemo demo = new DateTimeDemo();
        System.out.format("\nTime in milliseconds since epoch: %s", demo.getCurrentTimeInMilliseconds());
        System.out.format("\nTime in milliseconds since epoch using Instant: %s ", demo.getCurrentTimeUsingInstant());
        System.out.format("\nCurrent Date and time using Date Object: %s ", demo.getCurrentTimeUsingObject());
        System.out.format("\nCurrent local Date : %s ", demo.getLocalDate());
        System.out.format("\nCurrent local Date zone specific : %s ", demo.getZoneSpecificLocalDate());
    }

    private long getCurrentTimeUsingInstant() {
        Instant now = Instant.now();
        return now.toEpochMilli();
    }

    private LocalDateTime getZoneSpecificLocalDate() {
        return LocalDateTime.now();
    }

    private LocalDate getLocalDate() {
        return LocalDate.now();
    }

    private String getCurrentTimeUsingObject() {
        Date today = new Date();
        return (today.toString());
    }

    private Long getCurrentTimeInMilliseconds() {
        return System.currentTimeMillis();
    }
}
