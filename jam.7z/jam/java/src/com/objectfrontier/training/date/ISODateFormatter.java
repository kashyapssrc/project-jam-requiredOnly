package com.objectfrontier.training.date;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ISODateFormatter {

    public static void main(String[] args) {
        ISODateFormatter formatter = new ISODateFormatter();
        LocalDate today = LocalDate.now();
        formatter.foramtToISO(today);
    }

    private void foramtToISO(LocalDate today) {
        DateTimeFormatter basicFormatter = DateTimeFormatter.BASIC_ISO_DATE;
        System.out.println(basicFormatter.format(today));
        DateTimeFormatter seperatedFormatter = DateTimeFormatter.ISO_DATE;
        System.out.println(seperatedFormatter.format(today));
        DateTimeFormatter localFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
        System.out.println(localFormatter.format(today));
        DateTimeFormatter ordinalFormatter = DateTimeFormatter.ISO_ORDINAL_DATE;
        System.out.println(ordinalFormatter.format(today));
        DateTimeFormatter weekFormatter = DateTimeFormatter.ISO_WEEK_DATE;
        System.out.println(weekFormatter.format(today));
    }
}
