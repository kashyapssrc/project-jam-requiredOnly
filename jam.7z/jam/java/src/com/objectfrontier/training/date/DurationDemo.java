package com.objectfrontier.training.date;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;

public class DurationDemo {

    public static void main(String[] args) {

        LocalDateTime oldDate = LocalDateTime.of(2018, Month.AUGUST, 31, 10, 20, 55);
        LocalDateTime newDate = LocalDateTime.now();
        Duration duration = Duration.between(oldDate, newDate);
        System.out.println(duration.toDays());
    }
}
