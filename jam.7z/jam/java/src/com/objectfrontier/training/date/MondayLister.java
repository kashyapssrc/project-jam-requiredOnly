package com.objectfrontier.training.date;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MondayLister {

    public static void main(String[] args) {
        MondayLister lister = new MondayLister();
        Year year = Year.now();
        YearMonth month = year.atMonth(Month.APRIL);
        List<LocalDate> listOfMondays = lister.getListOfMondays(month);
        System.out.println(listOfMondays);
        for (LocalDate monday : listOfMondays) {
            lister.formatDate(monday);
        }
    }

    private void formatDate(LocalDate monday) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
        String date = formatter.format(monday);
        System.out.println(date);
    }

    private List<LocalDate> getListOfMondays(YearMonth month) {
        List<LocalDate> mondays = new ArrayList<>();
        DayOfWeek monday = DayOfWeek.MONDAY; 
        for (int index = 1; index < month.lengthOfMonth(); index++) {
            LocalDate day = month.atDay(index);
            if (day.getDayOfWeek() == monday) {
                mondays.add(day);
            }
        }
        return mondays;
    }
}
