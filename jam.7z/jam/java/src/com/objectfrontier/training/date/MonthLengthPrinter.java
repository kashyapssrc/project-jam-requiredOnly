package com.objectfrontier.training.date;

import java.time.Year;

public class MonthLengthPrinter {

    public static void main(String[] args) {
        MonthLengthPrinter lengthPrinter = new MonthLengthPrinter();
        Year year = Year.now();
        lengthPrinter.getAllMonthsLength(year);
    }

    private void getAllMonthsLength(Year year) {
        for (int index = 1; index < 13; index++) {
            System.out.format("%s: %d%n", year.atMonth(index).getMonth(), year.atMonth(index).lengthOfMonth());
        }
    }
}
