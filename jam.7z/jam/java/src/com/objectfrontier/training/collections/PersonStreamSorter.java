package com.objectfrontier.training.collections;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PersonStreamSorter {

    public static void main(String[] args) {

        List<Person> personList = Person.createRoster();
        List<Person> sortedPerson = personList.stream().
                                    sorted(Comparator.comparing(person -> ((Person) person).getAge()).reversed()).
                                    collect(Collectors.toList());
        System.out.println(sortedPerson);
    }

}
