package com.objectfrontier.training.collections;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

public class RandomNumbersDemo {

    private IntStream getStream(List<Integer> randomNumbers) {
        return randomNumbers.stream().mapToInt(Integer :: intValue);
    }

    private int findSum(List<Integer> randomNumbers) {

        int sum = getStream(randomNumbers).sum();
        return sum;
    }

    private int findMinimumValue(List<Integer> randomNumbers) {

        int minimumValue = getStream(randomNumbers).min().getAsInt();
        return minimumValue;
    }

    private int findMaximumValue(List<Integer> randomNumbers) {

        int maximumValue = getStream(randomNumbers).max().getAsInt();
        return maximumValue;
    }

    public static void main(String[] args) {

        List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 25, 78);
        RandomNumbersDemo demo = new RandomNumbersDemo();
        int sum = demo.findSum(randomNumbers);
        System.out.format("The sum of all values in given list: %d\n", sum);

        int minValue = demo.findMinimumValue(randomNumbers);
        System.out.format("The minimum value in the given list: %d\n", minValue);

        int maxValue = demo.findMaximumValue(randomNumbers);
        System.out.format("The minimum value in the given list: %d\n", maxValue);
    }
}
