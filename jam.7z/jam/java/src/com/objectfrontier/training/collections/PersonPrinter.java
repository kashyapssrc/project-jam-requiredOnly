package com.objectfrontier.training.collections;

import java.util.Iterator;
import java.util.List;

public class PersonPrinter {

    public static void main(String[] args) {
        PersonPrinter printer = new PersonPrinter();
        List<Person> person = Person.createRoster();

        printer.printUsingForEach(person);
        printer.printUsingIterator(person);
    }

    private void printUsingForEach(List<Person> personList) {
            personList.stream().forEach((person) -> {System.out.println(person.getName());});
        }

    private void printUsingIterator(List<Person> personList) {
        Iterator<Person> iterator = personList.iterator(); 
        System.out.println("List elements : "); 
        iterator.forEachRemaining(person -> {System.out.print(person.getName() + " ");});
    }
}
