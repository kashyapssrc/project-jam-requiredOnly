package com.objectfrontier.training.collections;

import java.util.ArrayList;

public class ArrayListDemo {

    public void printArrayList(ArrayList<Object> objectList) {
        for (Object object : objectList) {
            System.out.println(object);
        }
    }

    public static void main(String[] args) {

        ArrayListDemo demo = new ArrayListDemo();

        // Following array list can have objects of any type
        ArrayList<Object> objects = new ArrayList<>(5);

        // adding an integer object to the array list
        objects.add(new Integer(1));

        // adding a string object to the array list
        objects.add("hello");
        demo.printArrayList(objects);

        // to get a particular object from the array list the exact type of that particular object needs to be known 
        int index = 1;
        String name = (String) objects.get(index);
//        System.out.println("Object at the index " + index + ":" + name);
        System.out.format("Object at the index %d : %s", index, name);

        // Following array list can have only string objects
        ArrayList<String> staffs = new ArrayList<>();

        // adding string objects to the array list
        staffs.add("Jayanth");
        staffs.add("Praveen");

        //demo.printArrayList(staffList)
        System.out.println(staffs);

        // getting a particular object from the array list is comparatively easy
        String staffName = (String) staffs.get(index);
        System.out.println("Staff Name in index 1 is " + staffName);

        // adding a string to a string array list in the specified index 
        staffs.add(index, "Pradeep");
        System.out.println("The list of names of the staff :" + staffs);
    }
}
