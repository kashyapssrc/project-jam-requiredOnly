package com.objectfrontier.training.collections;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class PersonRemover {

    public static void main(String[] args) {
        PersonRemover remover = new PersonRemover();
        List<Person> person = Person.createRoster();
        List<Person> newRoster = new ArrayList<>();
        newRoster.add(new Person("John",
                                  IsoChronology.INSTANCE.date(1980, 6, 20),
                                  Person.Sex.MALE,
                                  "john@example.com"));
        newRoster.add(new Person("Jade",
                                  IsoChronology.INSTANCE.date(1990, 7, 15),
                                  Person.Sex.FEMALE,
                                  "jade@example.com"));
        newRoster.add(new Person("Donald",
                                  IsoChronology.INSTANCE.date(1991, 8, 13),
                                  Person.Sex.MALE,
                                  "donald@example.com"));
        newRoster.add(new Person("Bob",
                                  IsoChronology.INSTANCE.date(2000, 9, 12),
                                  Person.Sex.MALE,
                                  "bob@example.com"));
        remover.printList(newRoster);
        remover.printList(person);
        List<Person> uniquePeople = remover.removeCommonPerson(newRoster, person);
        remover.printList(uniquePeople);
    }

    private void printList(List<Person> newRoster) {
        System.out.println(newRoster);
    }

    private List<Person> removeCommonPerson(List<Person> roster, List<Person> person) {
        List<Person> allPeople = new ArrayList<>(roster);
        allPeople.addAll(person);

        List<Person> commonPerson = new ArrayList<>(roster);
        commonPerson.retainAll(person);

        allPeople.removeAll(commonPerson);
        return allPeople;
    }
}
