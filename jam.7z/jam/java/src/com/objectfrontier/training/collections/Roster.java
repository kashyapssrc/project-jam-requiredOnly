package com.objectfrontier.training.collections;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

public class Roster {

    public static void main(String[] args) {
        Roster roster = new Roster();
        List<Person> person = Person.createRoster();
        List<Person> newRoster = new ArrayList<>();
        newRoster.add(new Person("John",
                                  IsoChronology.INSTANCE.date(1980, 6, 20),
                                  Person.Sex.MALE,
                                  "john@example.com"));
        newRoster.add(new Person("Jade",
                                  IsoChronology.INSTANCE.date(1990, 7, 15),
                                  Person.Sex.FEMALE,
                                  "jade@example.com"));
        newRoster.add(new Person("Donald",
                                  IsoChronology.INSTANCE.date(1991, 8, 13),
                                  Person.Sex.MALE,
                                  "donald@example.com"));
        Person bob = new Person("Bob",
                IsoChronology.INSTANCE.date(2000, 9, 12),
                Person.Sex.MALE,
                "bob@example.com");
        newRoster.add(bob);
        roster.addToCollection(newRoster, person);
        roster.printRoster(newRoster);

        roster.checkIfContains(newRoster,bob);

        roster.removeFromCollection(newRoster);
        roster.printRoster(newRoster);
    }

    private void checkIfContains(List<Person> newRoster, Person bob) {
        boolean isPresent = newRoster.contains(bob);
        System.out.println(isPresent);
    }

    private void removeFromCollection(List<Person> newRoster) {
        newRoster.removeAll(newRoster);
    }

    private void addToCollection(List<Person> newRoster, List<Person> person) {
        newRoster.addAll(person);
    }

    private void printRoster(List<Person> person) {
        System.out.println(person);
    }
}
