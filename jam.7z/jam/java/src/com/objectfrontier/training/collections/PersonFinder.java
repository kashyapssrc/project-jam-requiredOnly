package com.objectfrontier.training.collections;

import java.util.List;
import java.util.stream.Collectors;

import com.objectfrontier.training.collections.Person.Sex;

public class PersonFinder{

    private Person findFirstMale(List<Person> personList) {
        Person firstMan = personList.stream().
                          filter(person -> { return person.getGender() == Sex.MALE; }).
                          findFirst().get();
        return firstMan;
    }

    private Person findLastMale(List<Person> personList) {
        List<Person> lastMan = personList.stream().
                               filter(person -> { return person.getGender() == Sex.MALE; }).
                               collect(Collectors.toList());
        return lastMan.get(lastMan.size() - 1);
    }

    private Person findRandomMan(List<Person> personList) {
        Person man = personList.stream().
                     filter(person -> { return person.getGender() == Sex.MALE; }).
                     findAny().get();
        return man;
    }

    public static void main(String[] args) {

        PersonFinder finder = new PersonFinder();
        List<Person> person = Person.createRoster();
        Person firstPerson = finder.findFirstMale(person);
        System.out.println(firstPerson.getName());

        Person lastPerson = finder.findLastMale(person);
        System.out.println(lastPerson.getName());

        Person randomPerson = finder.findRandomMan(person);
        System.out.println(randomPerson.getName());
    }
}
