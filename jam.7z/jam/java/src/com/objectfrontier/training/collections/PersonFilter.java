package com.objectfrontier.training.collections;

import java.util.List;
import java.util.stream.Collectors;

import com.objectfrontier.training.collections.Person.Sex;

public class PersonFilter {

    public List<Person> filterPerson() {
        List<Person> personList = Person.createRoster();
        List<Person> filteredList = personList.stream().
                                    filter(person -> { return person.getGender() == Sex.MALE; }).
                                    filter(person -> { return person.getAge() > 21; }).
                                    collect(Collectors.toList());
        return filteredList;
    }

    public static void main(String[] args) {

        PersonFilter filter = new PersonFilter();
        List<Person> filteredList = filter.filterPerson();

        for (Person person : filteredList ) {
            System.out.println(person.getName());
        }
    }
}
