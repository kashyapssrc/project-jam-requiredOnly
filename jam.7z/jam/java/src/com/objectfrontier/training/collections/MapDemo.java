package com.objectfrontier.training.collections;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {
    private final static Map<Integer,String> map = new HashMap<>();;
    public static void main(String args[]) {
        map.put(100,"Amit");
        map.put(101,"Vimal");
        for(Map.Entry m:map.entrySet()) {
         System.out.println(m.getKey() +" " + m.getValue());
        }
    }
}
