package com.objectfrontier.training.collections;

public class GenericsWildCardDemo<T>
{
    T object;
    GenericsWildCardDemo(T object) {
        this.object = object;
    }

    public T getObject() {
        return this.object; 
    }

    public static void main (String[] args) {

        GenericsWildCardDemo <Integer> integerObject = new GenericsWildCardDemo<Integer>(15);
        System.out.println(integerObject.getObject());

        GenericsWildCardDemo <String> stringObject = new GenericsWildCardDemo<String>("Fifteen");
        System.out.println(stringObject.getObject());
    }
}
