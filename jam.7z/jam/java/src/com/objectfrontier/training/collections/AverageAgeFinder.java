package com.objectfrontier.training.collections;

import java.util.List;

public class AverageAgeFinder {

    public static void main(String[] args) {

        AverageAgeFinder finder = new AverageAgeFinder();
        List<Person> person = Person.createRoster();
        double averageAge = finder.calculateAverageAge(person);
        System.out.println(averageAge);
    }

    private double calculateAverageAge(List<Person> person) {
        double averageAge = person.stream().
                            mapToInt(Person :: getAge).
                            average().
                            getAsDouble();
        return averageAge;
    }
}
