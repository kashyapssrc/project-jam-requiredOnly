package com.objectfrontier.training.collections;

import java.util.List;
import java.util.stream.Collectors;

public class MinimalPersonCollector {

    public static void main(String[] args) {
        MinimalPersonCollector collector = new MinimalPersonCollector();
        collector.collectMinimalPerson();
    }

    private void collectMinimalPerson() {
        List<Person> roster = Person.createRoster();
        List<MinimalPersonPrinter> minimalPerson = roster.stream().
                                                          map(Person::getMinimalPerson).
                                                          collect(Collectors.toList());
        System.out.println(minimalPerson);
    }
}
