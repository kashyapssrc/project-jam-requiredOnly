package com.objectfrontier.training.collections;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PersonSorter{

    public static void main(String[] args) {

        PersonSorter sorter = new PersonSorter();
        List<Person> person = Person.createRoster();
        List<Person> sortedPerson = sorter.sortAccordingToAgeUsingComparator(person);
        System.out.println(sortedPerson);
    }

    private List<Person> sortAccordingToAgeUsingComparator(List<Person> personList) {
        Collections.sort(personList, Comparator.comparing(person -> ((Person) person).getAge()).reversed());
        return personList;
    }
} 
