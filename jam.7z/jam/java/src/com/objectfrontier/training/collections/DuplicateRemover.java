package com.objectfrontier.training.collections;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DuplicateRemover {

    public static void main(String[] args) {
        List<Integer> randomNumbers = Arrays.asList(1, 6, 10, 1, 25, 78, 10, 25);

        DuplicateRemover remover = new DuplicateRemover();
        List<Integer> uniqueNumbers = remover.removeDuplicates(randomNumbers);
        System.out.println(uniqueNumbers);
    }

    private List<Integer> removeDuplicates(List<Integer> randomNumbers) {
        List<Integer> uniqueNumbers = randomNumbers.stream().distinct().collect(Collectors.toList());
        return uniqueNumbers;
    }
}
