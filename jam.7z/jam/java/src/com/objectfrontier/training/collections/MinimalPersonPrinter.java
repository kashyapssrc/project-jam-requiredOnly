package com.objectfrontier.training.collections;

import java.util.List;

public class MinimalPersonPrinter {

    public String name;
    public String emailAddress;

    public static void main(String[] args) {
        MinimalPersonPrinter personPrinter = new MinimalPersonPrinter();
        personPrinter.printMinimalPerson();
    }

    private void printMinimalPerson() {
        List<Person> roster = Person.createRoster();
        roster.stream().
               map(Person::getMinimalPerson).
               forEach(person -> System.out.format("%s\t%s%n", person.name ,person.emailAddress));
    }
}
