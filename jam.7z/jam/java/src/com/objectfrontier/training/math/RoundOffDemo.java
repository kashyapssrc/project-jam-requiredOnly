package com.objectfrontier.training.math;

import java.math.BigDecimal;

public class RoundOffDemo {

    public static void main(String[] args) {
        RoundOffDemo demo = new RoundOffDemo();
        BigDecimal value = new BigDecimal(450.908561056);
        int decimalPlace = 3;
        BigDecimal roundedOffInt = demo.roundOff(value,decimalPlace);
        System.out.println("The roundedOff bigDecimal is: " + roundedOffInt);
        demo.displayDetails(value);
    }

    private void displayDetails(BigDecimal value) {
        BigDecimal absoluteValue = value.abs();
        System.out.println("the absolute value:" + absoluteValue);

        BigDecimal ceiling = value.setScale(4, BigDecimal.ROUND_CEILING);
        System.out.println("Ceiling value : " + ceiling);

        BigDecimal floor = value.setScale(4, BigDecimal.ROUND_FLOOR);
        System.out.println("Floor value : " + floor);

        float rint = value.floatValue();
        System.out.println("Rint value: " + rint);

        BigDecimal anotherValue = new BigDecimal(5437.98683609079);
        BigDecimal minValue = value.min(anotherValue);
        System.out.println("Min : " + minValue);
        BigDecimal maxValue = value.max(anotherValue);
        System.out.println("Max: " + maxValue);
        
    }

    private BigDecimal roundOff(BigDecimal value, int decimalPlace) {
        value = value.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return value; 
    }
}
