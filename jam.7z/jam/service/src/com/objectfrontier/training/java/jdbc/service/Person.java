package com.objectfrontier.training.java.jdbc.service;

import java.sql.Date;
import java.sql.Time;

public class Person {

    long id;
    String firstName;
    String lastName;
    String email;
    Date birthDate;
    Time createdDate;
    Address address;

    public Person(String firstName, String lastName, String email, Date birthDate, Address address) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.birthDate = birthDate;
        this.address = address;
    }

    public Person(long id, String firstName, String lastName, String email, Date birthDate, Address address) {

        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.birthDate = birthDate;
        this.address = address;
    }

    public Person() {
    }

    public long getId() {
        return this.id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getEmail() {
        return this.email;
    }

    public Date getBirthDate() {
        return this.birthDate;
    }

    public Time getCreatedDate() {
        return this.createdDate;
    }

    public Address getAddress() {
        return this.address;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setCreatedDate(Time createdDate) {
        this.createdDate = createdDate;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Address [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "birthDate=" + birthDate + "]";
    }
}
