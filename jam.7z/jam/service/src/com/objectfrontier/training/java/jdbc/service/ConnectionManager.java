package com.objectfrontier.training.java.jdbc.service;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionManager {

    Connection con = null;
    public Connection openConnection() {

        try {
            String url  = "jdbc:mysql://pc1620:3306/jayanth_subramanian?useSSL=false";
            Properties connectionProperties = new Properties();
            InputStream inStream = ConnectionManager.class.getResourceAsStream("ConnectionProperties.properties");
            connectionProperties.load(inStream);
            con = DriverManager.getConnection(url, connectionProperties);
            con.setAutoCommit(false);
        } catch (Exception exception) {
            throw new RuntimeException("Invalid Connection" + exception.getMessage());
        }
        return con;
    }

    public void closeConnection() {

        try {
            con.close();
        } catch (Exception exception) {
            throw new RuntimeException("Connection is not open");
        }
    }
}
