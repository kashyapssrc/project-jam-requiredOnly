package com.objectfrontier.training.java.jdbc.service;

import java.util.ArrayList;
import java.util.List;

public class AppException extends RuntimeException {

    private static final long serialVersionUID = 1L;
    List<Error> errorCodes = new ArrayList<>();
    Throwable cause;

    public AppException(List<Error> errorCodes) {
        super();
        this.errorCodes = errorCodes;
    }

    public AppException(Error errorCode, Throwable cause) {
        super(errorCode.getErrorMessage(), cause);
        if (errorCodes != null && errorCodes.size() != 0) {
            errorCodes = new ArrayList<>();
            errorCodes.add(errorCode);
            this.cause = cause;
        }
    }

    public List<Error> getErrorCodes() {
        return errorCodes;
    }

    public void setErrorCodes(List<Error> errorCodes) {
        this.errorCodes = errorCodes;
    }
}
