package com.objectfrontier.training.java.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.objectfrontier.training.java.jdbc.test.AddressServiceTest;

public class PersonService {

    AddressService addressService = new AddressService();
    AddressServiceTest addressServiceTest = new AddressServiceTest();

    private boolean isEmpty(Object value) {
        return Objects.isNull(value) || "".equals(value);
    }
    private void validate(Person person, Connection con) throws Exception {
        List<Error> errors = new ArrayList<>();
        if (isEmpty(person.getFirstName())) {
            errors.add(Error.INVALID_FIRST_NAME);
        }

        if (isEmpty(person.getLastName()))  {
            errors.add(Error.INVALID_LAST_NAME);
        }

        if (isEmpty(person.getEmail())) {
            errors.add(Error.INVALID_EMAIL);
        }

        if (Objects.isNull(person.getBirthDate())) {
            errors.add(Error.INVALID_BIRTH_DATE);
        }

        if (person.getFirstName() == person.getLastName()) {
            errors.add(Error.INVALID_NAME);
        }

        if (isEmailDuplicate(person, con)) {
            errors.add(Error.INVALID_EMAIL);
        }

        if (isNameDuplicate(person, con)) {
            errors.add(Error.INVALID_NAME);
        }

        if (errors.size() > 0) { throw new AppException(errors); }
    }

    private void validateId(long id, Connection con) {
        if (id == 0) {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_PERSON_ID);
            throw new AppException(errors);
        }
    }

    public boolean isEmailDuplicate(Person person, Connection con) throws Exception {

        try {
        String query = new StringBuilder().append("SELECT COUNT(email)")
                                          .append(" FROM person       ")
                                          .append(" WHERE email = ?   ")
                                          .toString();

            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, person.getEmail());
            ResultSet result = statement.executeQuery();
            result.next();
            int count = result.getInt("COUNT(email)");
            if (count > 0) {
                return true;
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return false;
    }


    public boolean isNameDuplicate(Person person, Connection con) throws Exception {

        try {
        String query = new StringBuilder().append("SELECT COUNT(id)                       ")
                                          .append(" FROM person                           ")
                                          .append(" WHERE first_name = ? AND last_name = ?")
                                          .toString();

            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            ResultSet result = statement.executeQuery();
            result.next();
            int count = result.getInt("COUNT(id)");
            if (count > 0) {
                return true;
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return false;
    }

    public Person create(Person person, Connection con) throws Exception {

        String query = new StringBuilder().append("INSERT INTO person (first_name   ")
                                          .append("                   , last_name   ")
                                          .append("                   , email       ")
                                          .append("                   , birth_date  ")
                                          .append("                   , address_id) ")
                                          .append("VALUES (?, ?, ?, ?, ?)           ")
                                          .toString();

        try {
            validate(person, con);

            PreparedStatement statement = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            Address address = addressService.create(person.getAddress(), con);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate(4, person.getBirthDate());
            person.setAddress  (address);
            statement.setLong(5, person.address.getId());
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();
            long generatedId = 0;
            if ((rs.next()) && (rs != null)) {
                generatedId = rs.getLong(1);
            }
            person.setId(generatedId);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public Person update(Person person, Connection con) throws Exception {

        String query = new StringBuilder().append("UPDATE person SET first_name = ?")
                                          .append(", last_name = ?                 ")
                                          .append(", email = ?                     ")
                                          .append(", birth_date = ?                ")
                                          .append(" WHERE id = ?                   ")
                                          .toString();

        try {
            validateId(person.getId(), con);
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, person.getFirstName());
            statement.setString(2, person.getLastName());
            statement.setString(3, person.getEmail());
            statement.setDate(4, person.getBirthDate());
            statement.setLong(5, person.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return person;
    }

    public Person read(Person person, boolean includeAddress, Connection con) throws Exception{

        Person selectedPerson = new Person();
        try {
            validateId(person.getId(), con);
            String query = new StringBuilder().append("SELECT id, first_name, last_name, email,")
                                              .append(" birth_date, created_date, address_id   ")
                                              .append(" FROM person WHERE id = ?               ")
                                              .toString();
            if (includeAddress) {

                 PreparedStatement statement = con.prepareStatement(query);
                 statement.setLong(1, person.getId());
                 Address address = addressService.read(person.getAddress(), con);
                 ResultSet result = statement.executeQuery();
                 result.next();
                 selectedPerson.setId(result.getLong("id"));
                 selectedPerson.setFirstName(result.getString("first_name"));
                 selectedPerson.setLastName(result.getString("last_name"));
                 selectedPerson.setEmail(result.getString("email"));
                 selectedPerson.setBirthDate(result.getDate("birth_date"));
                 selectedPerson.setCreatedDate(result.getTime("created_date"));
                 selectedPerson.setAddress(address);
            } else {

                PreparedStatement statement = con.prepareStatement(query);
                statement.setLong(1, person.getId());
                ResultSet result = statement.executeQuery();
                result.next();
                selectedPerson.setId(result.getLong("id"));
                selectedPerson.setFirstName(result.getString("first_name"));
                selectedPerson.setLastName(result.getString("last_name"));
                selectedPerson.setEmail(result.getString("email"));
                selectedPerson.setBirthDate(result.getDate("birth_date"));
                selectedPerson.setCreatedDate(result.getTime("created_date"));

            }
        } catch (SQLException e) {
             throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return selectedPerson;
    }

    public List<Person> readAll(boolean includeAddress, Connection con) throws Exception{

        List<Person> resultRecords = new ArrayList<>();

        try {

            if (Objects.isNull(con)) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DATABASE_ERROR);
                throw new AppException(errors);
            }

            String query = new StringBuilder().append("SELECT id, address_id, first_name, last_name, email,")
                    .append(" birth_date, created_date, address_id               ")
                    .append(" FROM person                                        ")
                    .toString();
            if (includeAddress) {

                PreparedStatement personStatement = con.prepareStatement(query);
                ResultSet result = personStatement.executeQuery();
                while (result.next()) {
                    Person person = new Person();
                    Address address = addressService.read(person.getAddress(), con);
                    person.setId(result.getLong("id"));
                    person.setFirstName(result.getString("first_name"));
                    person.setLastName(result.getString("last_name"));
                    person.setEmail(result.getString("email"));
                    person.setBirthDate(result.getDate("birth_date"));
                    person.setCreatedDate(result.getTime("created_date"));
                    person.setAddress(address);
                    resultRecords.add(person);
                }
            } else {

                PreparedStatement statement = con.prepareStatement(query);
                ResultSet result = statement.executeQuery();
                while (result.next()) {
                    Person person = new Person();
                    person.setId(result.getLong("id"));
                    person.setFirstName(result.getString("first_name"));
                    person.setLastName(result.getString("last_name"));
                    person.setEmail(result.getString("email"));
                    person.setBirthDate(result.getDate("birth_date"));
                    person.setCreatedDate(result.getTime("created_date"));
                    resultRecords.add(person);
                }
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecords;
    }

    public void delete(Person person, Connection con) throws Exception {

        try {
            validateId(person.getId(), con);
            String query = new StringBuilder().append("DELETE FROM person    ")
                                              .append(" WHERE address_id = ? ")
                                              .toString();

            PreparedStatement statement = con.prepareStatement(query);
            statement.setLong(1, person.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }
}
