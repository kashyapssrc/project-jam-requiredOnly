package com.objectfrontier.training.java.jdbc.service;

public enum Error {

    INVALID_ADDRESS_ID  (101, "ID cannot be empty"                     ),
    INVALID_STREET      (102, "Street cannot be null"                  ),
    INVALID_CITY        (103, "City cannot be null"                    ),
    INVALID_PINCODE     (104, "Pincode cannot be empty"                ),
    INVALID_PERSON_ID   (101, "ID cannot be empty"                     ),
    INVALID_FIRST_NAME  (106, "First Name cannot be empty"             ),
    INVALID_LAST_NAME   (107, "Last Name cannot be empty"              ),
    INVALID_EMAIL       (108, "Email cannot be empty"                  ),
    INVALID_BIRTH_DATE  (109, "Birth Date cannot be empty"             ),
    INVALID_NAME        (110, "First name and Last Name cannot be same"),
    DUPLICATE_EMAIL     (111, "Email already exists"                   ),
    DATABASE_ERROR      (112, "Database error"                         ),
    INVALID_SEARCH_INPUT(113, "Search input cannot be null"            );

    int errorCode;
    String errorMessage;

    Error(int errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
};
