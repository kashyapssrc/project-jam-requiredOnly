package com.objectfrontier.training.java.jdbc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AddressService {

    private void validate(Address address) {
        List<Error> errors = new ArrayList<>();

        if (Objects.isNull(address.getStreet())) {
            errors.add(Error.INVALID_STREET);
        }

        if (Objects.isNull(address.getCity())) {
            errors.add(Error.INVALID_CITY);
        }

        if (address.getPincode() == 0) {
            errors.add(Error.INVALID_PINCODE);
        }
        if (errors.size() > 0) { throw new AppException(errors); }
    }

    private void validateId(long id, Connection con) throws Exception {

        if (id == 0) {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_ADDRESS_ID);
            throw new AppException(errors);
        }
    }

    public Address create(Address address, Connection con) throws Exception {

        String query = new StringBuilder().append("INSERT INTO address (street    ")
                                          .append("                     , city    ")
                                          .append("                     , pincode)")
                                          .append("VALUES (?, ?, ?)               ")
                                          .toString();

        try {
            validate(address);
            PreparedStatement statement = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPincode());
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();
            long generatedId = 0;
            if ((rs.next()) && (rs != null)) {
                generatedId = rs.getLong(1);
            }
            address.setId(generatedId);
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public Address update(Address address, Connection con) throws Exception {

        String query = new StringBuilder().append("UPDATE address SET street = ?, city = ?, pincode = ?")
                                          .append(" WHERE id = ?                                       ")
                                          .toString();

        try {
            validateId(address.getId(), con);

            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, address.getStreet());
            statement.setString(2, address.getCity());
            statement.setInt(3, address.getPincode());
            statement.setLong(4, address.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public Address read(Address address, Connection con) throws Exception {

        Address selectedAddress = new Address();
        String query = new StringBuilder().append("SELECT id, street, city, pincode")
                                          .append(" FROM address WHERE id = ?      ")
                                          .toString();

        try {
            validateId(address.getId(), con);

            PreparedStatement statement = con.prepareStatement(query);
            statement.setLong(1, address.getId());

            ResultSet result = statement.executeQuery();
            result.next();
            selectedAddress.setId(result.getLong("id"));
            selectedAddress.setStreet(result.getString("street"));
            selectedAddress.setCity(result.getString("city"));
            selectedAddress.setPincode(result.getInt("pincode"));
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return address;
    }

    public List<Address> search(String[] fields, String searchText, Connection con) throws Exception {

        List<Address> addresses = new ArrayList<>();
        StringBuilder sb = new StringBuilder();

        try {
            if (Objects.isNull(searchText) || "".equals(searchText)) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.INVALID_SEARCH_INPUT);
                throw new AppException(errors);
            }

            for (String field : fields) {
                sb.append(String.format("%s LIKE ? OR ", field));
            }

            String selectQuery = (String) sb.subSequence(0, sb.length() - 3);
            String query = new StringBuilder().append("SELECT id, street, city, pincode")
                                              .append(" FROM address WHERE ")
                                              .append(selectQuery)
                                              .toString();
            PreparedStatement statement = con.prepareStatement(query);
            for (int index = 1; index <= fields.length; index++) {
                statement.setString(index, "%" + searchText + "%");
            }
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                address.setId(result.getLong("id"));
                address.setStreet(result.getString("street"));
                address.setCity(result.getString("city"));
                address.setPincode(result.getInt("pincode"));
                addresses.add(address);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return addresses;
    }

    public List<Address> readAll(Connection con) throws Exception {

        List<Address> resultRecords = new ArrayList<>();
        try {

            if (Objects.isNull(con)) {
                List<Error> errors = new ArrayList<>();
                errors.add(Error.DATABASE_ERROR);
                throw new AppException(errors);
            }

            String query = new StringBuilder().append("SELECT id, street, city, pincode")
                                              .append(" FROM address                   ")
                                              .toString();

            PreparedStatement statement = con.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Address address = new Address();
                address.setId(result.getLong("id"));
                address.setStreet(result.getString("street"));
                address.setCity(result.getString("city"));
                address.setPincode(result.getInt("pincode"));
                resultRecords.add(address);
            }
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
        return resultRecords;
    }

    public void delete(Address address, Connection con) throws Exception {

        try {
            validateId(address.getId(), con);
            String deleteQuery = new StringBuilder().append("DELETE FROM address")
                                                    .append(" WHERE id = ?      ")
                                                    .toString();

            PreparedStatement statement = con.prepareStatement(deleteQuery);
            statement.setLong(1, address.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new AppException(Error.DATABASE_ERROR, e.getCause());
        }
    }
}
