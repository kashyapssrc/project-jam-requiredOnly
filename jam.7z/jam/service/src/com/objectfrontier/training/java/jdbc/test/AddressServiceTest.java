package com.objectfrontier.training.java.jdbc.test;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.java.jdbc.service.Address;
import com.objectfrontier.training.java.jdbc.service.AddressService;
import com.objectfrontier.training.java.jdbc.service.AppException;
import com.objectfrontier.training.java.jdbc.service.ConnectionManager;
import com.objectfrontier.training.java.jdbc.service.Error;

@Test
public class AddressServiceTest {

    AddressService addressService;

    @BeforeClass
    private void initialize() {
        addressService = new AddressService();
    }

    @Test(dataProvider = "testCreate_positiveDP")
    private void testCreate_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try{
            Address actualResult = addressService.create(address, con);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCodes());
            con.rollback();
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() {
        return new Object[][] {
            { new Address (1,"Mint street", "Madras", 600235), new Address (1,"Mint street", "Madras", 600235) },
            { new Address (2,"Govind street", "Chennai", 600231), new Address (2,"Govind street", "Chennai", 600231) },
        };
    }

    @Test(dataProvider = "testCreate_negativeDP")
    private void testCreate_negative(Address address, AppException exception) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try{
            addressService.create(address,con);
            Assert.fail("Expected an exception.");
            con.rollback();
        } catch (AppException e) {
            Assert.assertEquals(exception.getErrorCodes(), e.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() {
        ArrayList<Error> errorListOne = new ArrayList<>();
        errorListOne.add(Error.INVALID_PINCODE);
        ArrayList<Error> errorListTwo = new ArrayList<>();
        errorListTwo.add(Error.INVALID_CITY);
        ArrayList<Error> errorListThree = new ArrayList<>();
        errorListThree.add(Error.INVALID_STREET);

        return new Object[][] {
            { new Address ("Mint street", "Madras", 0), new AppException(errorListOne) },
            { new Address ("Mint street", null, 600034), new AppException(errorListTwo) },
            { new Address (null, "Madras", 600034), new AppException(errorListThree) }
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP")
    private void testUpdate_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            Address actualResult = addressService.update(address, con);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() throws Exception {
        return new Object[][] {
            { new Address(1,"Mint street", "Madras", 600235), new Address(1,"Mint street", "Madras", 600235) },
        };
    }

    @Test(dataProvider = "testUpdate_negativeDP")
    private void testUpdate_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            addressService.update(address, con);
            Assert.fail("Expected an exception.");
            con.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() throws Exception {
        Address address = new Address();
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ADDRESS_ID);
        return new Object[][] {
            {address, new AppException(errors) }
        };
    }

    @Test(dataProvider = "testRead_positiveDP")
    private void testRead_positive(Address address, Address expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            Address actualResult = addressService.read(address, con);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        return new Object[][] {
            { new Address (2,"Govind street", "Chennai", 600231), new Address (2,"Govind street", "Chennai", 600231) }
        };
    }

    @Test(dataProvider = "testRead_negativeDP")
    private void testRead_negative(AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            Address address = new Address();
            addressService.read(address, con);
            Assert.fail("Expected an exception.");
            con.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ADDRESS_ID);
        return new Object[][] {
            { new AppException(errors) }
        };
    }

    @Test(dataProvider = "testReadAll_positiveDP")
    private void testReadAll_positive(List<Address> expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            List<Address> actualResult = addressService.readAll(con);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + expectedResult + e.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {
        List<Address> inputAddress = new ArrayList<>();
        inputAddress.add(new Address(2, "Govind street", "Chennai", 600231));

        return new Object[][] {
          { inputAddress }
      };
    }

    @Test(dataProvider = "testReadAll_negativeDP")
    private void testReadAll_negative(AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            addressService.readAll(null);
            Assert.fail("Expected an exception.");
            con.rollback();
      } catch (AppException e) {
          Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
      } finally {
          txn.closeConnection();
      }
    }

    @DataProvider
    private Object[][] testReadAll_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.DATABASE_ERROR);
      return new Object[][] {
          { new AppException(errors) }
      };
    }

    @Test(dataProvider = "testDelete_positiveDP")
    private void testDelete_positive(Address address) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            addressService.delete(address, con);
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + e.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() throws Exception {
        return new Object[][] {
            { new Address (1,"Mint street", "Madras", 600235) }
        };
    }

    @Test(dataProvider = "testDelete_negativeDP")
    private void testDelete_negative(Address address, AppException expectedException) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            addressService.delete(address,con);
            Assert.fail("Expected an exception.");
            con.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() throws Exception {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_ADDRESS_ID);
        Address address = new Address();
        return new Object[][] {
            { address, new AppException(errors) }
        };
    }

    @Test(dataProvider = "testSearch_positiveDP")
    private void testSearch_positive(String[] fields, String searchInput, List<Address> expectedResult) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            List<Address> actualResult = addressService.search(fields, searchInput, con);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
            con.commit();
        } catch (AppException e) {
            Assert.fail("Unexpected Exception for the given input.Expected result is " + e.getCause());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testSearch_positiveDP() throws Exception {
        List<Address> addressesSearchedByString = new ArrayList<>();
        List<Address> addressesSearchedByInteger = new ArrayList<>();
        addressesSearchedByString.add(new Address (2,"Govind street", "Chennai", 600231));
        addressesSearchedByInteger.add(new Address (2,"Govind street", "Chennai", 600231));

        return new Object[][] {
            { new String[] {"street", "city"}, "Gov", addressesSearchedByString },
            { new String[] {"pincode"}, "231", addressesSearchedByInteger },
        };
    }

    @Test(dataProvider = "testSearch_negativeDP")
    private void testSearch_negative(AppException exception) throws Exception {

        ConnectionManager txn = new ConnectionManager();
        Connection con = txn.openConnection();

        try {
            String[] fields = {"street", "city"};
            addressService.search(fields, null,con);
            Assert.fail("Expected an exception.");
            con.rollback();
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), exception.getErrorCodes());
        } finally {
            txn.closeConnection();
        }
    }

    @DataProvider
    private Object[][] testSearch_negativeDP() throws Exception {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_SEARCH_INPUT);
        return new Object[][] {
            { new AppException(errors) },
        };
    }
}
