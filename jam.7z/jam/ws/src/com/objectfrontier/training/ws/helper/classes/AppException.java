package com.objectfrontier.training.ws.helper.classes;

import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.ws.service.main.Error;

/**
 * @author keerthanar
 * @since  Oct 03, 2016
 */
public class AppException extends RuntimeException {

    private static final long serialVersionUID = 8422080821407553434L;

    private List<Error> errorCodes;
    public AppException(List<Error> errorCodes) {
        this.errorCodes = errorCodes;
    }

    public AppException(List<Error> errorCodes, Throwable cause) {
        super(cause);
        this.errorCodes = errorCodes;
    }

    public AppException(Error errorCode, Throwable cause) {
        super(cause);
        this.errorCodes = new ArrayList<>(1);
        errorCodes.add(errorCode);
    }

    public AppException(Throwable cause) {
        this(Error.UNKNOWN_ERROR, cause);
    }

    @Override
    public String getMessage() {
        return toString();
    }

    @Override
    public String toString() {
        return errorCodes.toString();
    }
}
