package com.objectfrontier.training.ws.service.test;

import java.sql.Connection;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.ws.service.main.Address;
import com.objectfrontier.training.ws.service.main.AppException;
import com.objectfrontier.training.ws.service.main.ConnectionManager;
import com.objectfrontier.training.ws.service.main.Error;
import com.objectfrontier.training.ws.service.main.Person;
import com.objectfrontier.training.ws.service.main.PersonService;

@Test
public class PersonServiceTest {

    PersonService personService;

    @BeforeClass
    private void setUp() {
        personService = new PersonService();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 0, groups = "create", threadPoolSize = 3, invocationCount = 1)
    private void testCreate_positive(Person person, Person expectedResult) throws Exception {

        Connection connection = ConnectionManager.getConnection();

        try {
            Person actualResult = personService.create(person, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testCreate_positiveDP() throws ParseException {
        return new Object[][] {
                                { new Person("praveen", "govind", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
                                  new Address("Mint street", "Madras", 600235)),
                                  new Person(1, "praveen", "govind", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
                                  new Address(1,"Mint street", "Madras", 600235))},
                                { new Person("jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-09"), "jay987", false,
                                  new Address("Govind street", "Chennai", 600231)),
                                  new Person(2, "jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-09"), "jay987", false,
                                  new Address(2,"Govind street", "Chennai", 600231))}
        };
    }

    @Test(dataProvider = "testCreate_negativeDP", priority = 1, groups = "create")
    private void testCreate_negative(Person person, AppException expectedException) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.create(person, connection);
            Assert.fail("Expected an exception.");
        } catch (AppException e) {
            Assert.assertEquals(expectedException.getErrorCodes(), e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testCreate_negativeDP() throws ParseException {
        ArrayList<Error> errorListOne = new ArrayList<>();
        errorListOne.add(Error.INVALID_EMAIL);
        errorListOne.add(Error.INVALID_NAME);
        ArrayList<Error> errorListTwo = new ArrayList<>();
        errorListTwo.add(Error.INVALID_LAST_NAME);
        ArrayList<Error> errorListThree = new ArrayList<>();
        errorListThree.add(Error.INVALID_FIRST_NAME);
        ArrayList<Error> errorListFour = new ArrayList<>();
        errorListFour.add(Error.INVALID_BIRTH_DATE);
        errorListFour.add(Error.INVALID_NAME);

        return new Object[][] {
                               { new Person(null, "subramanian", "ajay@gmail.com", Date.valueOf("1996-02-08"), "jay987", false,
                                 new Address("Govind street", "Chennai", 600231)),
                                 new AppException(errorListThree)},
                               { new Person("jayanth", null, "ajay@gmail.com", Date.valueOf("1996-02-08"), "jay987", false,
                                 new Address("Govind street", "Chennai", 600231)),
                                 new AppException(errorListTwo)},
                               { new Person("jayanth", "subramanian", null, Date.valueOf("1996-02-08"), "jay987", false,
                                 new Address("Govind street", "Chennai", 600231)),
                                 new AppException(errorListOne)},
                               { new Person("jayanth", "subramanian", "ajay@gmail.com", null, "jay987", false,
                                 new Address("Car street", "Tiruvannamalai", 606601)),
                                 new AppException(errorListFour)}
        };
    }

    @Test(dataProvider = "testUpdate_positiveDP", priority = 2, groups = "update")
    private void testUpdate_positive(Person person, Person expectedResult) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            Person actualResult = personService.update(person, connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        return new Object[][] {
                                { new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
                                  new Address("Mint street", "Chennai", 600345)),
                                  new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
                                  new Address("Mint street", "Chennai", 600345))}
        };
    }

    @Test(dataProvider = "testUpdate_negativeDP", priority = 3, groups = "update")
    private void testUpdate_negative(Person person, AppException expectedException) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.update(person, connection);
            Assert.fail("Expected an exception.");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testUpdate_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_PERSON_ID);
        return new Object[][] {
                                { new Person(0,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
                                  new Address("Mint street", "Chennai", 600345)),
                                  new AppException(errors)
                                }
        };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 4, groups = "read")
    private void testRead_positive(Person person, boolean includeAddress, Person expectedResult) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            Person actualResult = personService.read(person.getId(), connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        return new Object[][] {
            { new Person(2,"jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-09"), "jay987", false, null) ,false,
              new Person(2,"jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-09"), "jay987", false, null) },
            { new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false, null) ,false ,
              new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false, null) }
        };
    }

    @Test(dataProvider = "testRead_negativeDP", priority = 5, groups = "read")
    private void testRead_negative(Person person, AppException expectedException) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.read(person.getId(), connection);
            Assert.fail("Expected an exception.");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_PERSON_ID);
        return new Object[][] {
            { new Person(0, "jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-08"), "jay987", false, null),
              new AppException(errors)},
        };
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 6, groups = "readAll")
    private void testReadAll_positive(boolean includeAddress, List<Person> expectedResult) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            List<Person> actualResult = personService.readAll(connection);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input. Expected result is " + expectedResult + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {
        List<Person> inputPerson = new ArrayList<>();
        inputPerson.add( new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false, null));
        inputPerson.add( new Person(2,"jayanth", "subramanian", "jay@gmail.com", Date.valueOf("1996-08-09"), "jay987", false, null));
        return new Object[][] {
            { false, inputPerson }

        };
    }

    @Test(dataProvider = "testReadAll_negativeDP", priority = 7, groups = "readAll")
    private void testReadAll_negative(boolean includeAddress, AppException expectedException) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.readAll(connection);
            Assert.fail("Expected an exception.");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testReadAll_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.DATABASE_ERROR);
        return new Object[][] {
            { false, new AppException(errors) }

        };
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 8, groups = "delete")
    private void testDelete_positive(Person person) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.delete(person.getId(), connection);
        } catch (AppException e) {
            Assert.fail("Unexpected exception for given input " + e.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        return new Object[][] {
            { new Person(1,"praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
              new Address(1,"Mint street", "Chennai", 600345)) }
        };
    }

    @Test(dataProvider = "testDelete_negativeDP", priority = 9, groups = "delete")
    private void testDelete_negative(Person person, AppException expectedException) throws Exception {

        Connection connection = ConnectionManager.getConnection();
        try {
            personService.delete(person.getId(), connection);
            Assert.fail("Expected an exception.");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCodes(), expectedException.getErrorCodes());
        }
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_PERSON_ID);
        return new Object[][] {
            { new Person(0, "praveen", "govindh", "prav@gmail.com", Date.valueOf("1996-08-08"), "pra234", false,
              new Address("Mint street", "Chennai", 600345)),
              new AppException(errors)}
        };
    }
}
