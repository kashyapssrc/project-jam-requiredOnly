package com.objectfrontier.training.ws.servlets.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.ws.helper.classes.JsonUtil;
import com.objectfrontier.training.ws.service.main.ConnectionManager;
import com.objectfrontier.training.ws.service.main.Person;
import com.objectfrontier.training.ws.service.main.PersonService;

public class PersonServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    PersonService ps = new PersonService();

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Connection connection = ConnectionManager.getConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);

        Person person = JsonUtil.toObject(personJson, Person.class);
        PrintWriter out = response.getWriter();
//        try {
            person = ps.create(person, connection);
            out.write(JsonUtil.toJson(person));
//            ConnectionManager.releaseConnection(true);
//        } catch (Exception e) {
//            ConnectionManager.releaseConnection(false);
//            out.write(e.toString());
//        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        Connection connection = ConnectionManager.getConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String personJson = String.join("", jsonLines);
//        List<Error> errorCodes = new ArrayList<>();

        Person person= JsonUtil.toObject(personJson, Person.class);
        PrintWriter out = response.getWriter();
//        try {
            person = ps.update(person, connection);
            out.write(JsonUtil.toJson(person));
            ConnectionManager.releaseConnection(true);
//        } catch (Exception e) {
//            errorCodes.add(Error.INVALID_URL_EXCEPTION);
//            out.write(JsonUtil.toJson(errorCodes));
//            ConnectionManager.releaseConnection(false);
//        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Person> result = new ArrayList<>();
        response.setContentType("application/json");
        Connection connection = ConnectionManager.getConnection();
        System.out.println("connection is;" + connection);
        Person person = new Person();
        String personId = request.getParameter("id");
//        boolean includeAddress = Boolean.parseBoolean(request.getParameter("includeAddress"));
        PrintWriter out = response.getWriter();
//        List<Error> errorCodes = new ArrayList<>();

//        try {
            if (Objects.isNull(personId)) {
                result = ps.readAll(connection);
                out.write(JsonUtil.toJson(result));
            } else {
                long id = Long.parseLong(personId);
                person = ps.read(id, connection);
                out.write(JsonUtil.toJson(person));
            }
//        } catch (Exception e) {
//            errorCodes.add(Error.INVALID_URL_EXCEPTION);
//            out.write(JsonUtil.toJson(errorCodes));
//        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.getConnection();
        String personId = request.getParameter("id");
        PrintWriter out = response.getWriter();
//        List<Error> errorCodes = new ArrayList<>();

//        try {
            long id = Long.parseLong(personId);
            Person deletedPerson = ps.delete(id, connection);
            out.write(JsonUtil.toJson(deletedPerson));
//            ConnectionManager.releaseConnection(true);
//        } catch (Exception e) {
//            errorCodes.add(Error.INVALID_URL_EXCEPTION);
//            out.write(JsonUtil.toJson(errorCodes));
//            ConnectionManager.releaseConnection(false);
//        }
    }
}
