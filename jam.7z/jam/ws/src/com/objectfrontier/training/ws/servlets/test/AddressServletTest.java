package com.objectfrontier.training.ws.servlets.test;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.ws.helper.classes.HttpMethod;
import com.objectfrontier.training.ws.helper.classes.JsonUtil;
import com.objectfrontier.training.ws.helper.classes.RequestHelper;
import com.objectfrontier.training.ws.service.main.Address;
import com.objectfrontier.training.ws.service.main.Error;

public class AddressServletTest extends BaseServletTest {

        RequestHelper helper;
        AddressParser parser;

        @BeforeClass
        public void setUp() {
            helper = new RequestHelper();
            parser = new AddressParser();
        }
        public void doLogin() {
            helper = super.login();
        }

        @Test(dataProvider = "testCreate_positiveDP")
        public void testCreate_positive(String uri, Address input) throws Exception {

                Address address = helper.setMethod(HttpMethod.PUT)
                                          .setInput(input)
                                          .requestObject(uri, Address.class);
                Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(input));
       }

        @DataProvider
        private Object[][] testCreate_positiveDP() {

            String uri = "http://localhost:8080/ws/address.html";
            return new Object[][] {
                                    {uri, new Address("GK colony", "Chennai", 600012)}
                                  };
        }

        @Test(dataProvider = "testUpdate_positiveDP", priority = 1)
        public void testUpdate_positive(Address input) throws Exception {

            String uri = "http://localhost:8080/ws/address.html";
            Address address = helper.setMethod(HttpMethod.POST)
                                      .setInput(input)
                                      .requestObject(uri, Address.class);
            Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(input));
       }

        @DataProvider
        private Object[][] testUpdate_positiveDP() {
            return new Object[][] { {new Address(2,"Mary Street", "Salem", 631243)} };
        }

        @Test(dataProvider = "testDelete_positiveDP", priority = 2)
        public void testDelete_positive(Address input) throws Exception {

            String uri = "http://localhost:8080/ws/address.html?id=3";
            Address address = helper.setMethod(HttpMethod.DELETE)
                                      .requestObject(uri, Address.class);

            Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(input));
        }

        @DataProvider
        private Object[][] testDelete_positiveDP() {
            return new Object[][] { {new Address(3, "Tower Street", "Tiruvannamalai", 612123)} };
        }

        @Test(dataProvider = "testDelete_negativeDP", priority = 3)
        public void testDelete_negative(String uri, List<Error> expected) throws Exception {

            List<?> actual = helper.setMethod(HttpMethod.DELETE)
                                      .requestObject(uri, List.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        }

        @DataProvider
        private Object[][] testDelete_negativeDP() {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_URL_EXCEPTION);
            return new Object[][] {
                                    {"http://localhost:8080/ws/address.html?id", errors},
                                    {"http://localhost:8080/ws/address.html?id=", errors},
                                    {"http://localhost:8080/ws/address.html?id=abc", errors}
                                  };
        }

        @Test(dataProvider = "testRead_positiveDP", priority = 4)
        public void testRead_positive(Address input) throws Exception {

            String uri = "http://localhost:8080/ws/address.html?id=1";
            Address address = helper.setMethod(HttpMethod.GET)
                                      .requestObject(uri, Address.class);

            Assert.assertEquals(JsonUtil.toJson(address), JsonUtil.toJson(input));
        }

        @DataProvider
        private Object[][] testRead_positiveDP() {
            return new Object[][] {
                { new Address(1, "GK colony", "Chennai", 600012)}
            };
        }

        @Test(dataProvider = "testRead_negativeDP", priority = 5)
        public void testRead_negative(String uri, List<Error> expected) throws Exception {

            List<?> actual  = helper.setMethod(HttpMethod.GET)
                                      .requestObject(uri, List.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        }

        @DataProvider
        private Object[][] testRead_negativeDP() {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_URL_EXCEPTION);
            return new Object[][] {
                                    {"http://localhost:8080/ws/address.html?id", errors},
                                    {"http://localhost:8080/ws/address.html?id=", errors},
                                    {"http://localhost:8080/ws/address.html?id=abc", errors}
                                  };
        }

        @Test(dataProvider = "testReadAll_positiveDP", priority = 6)
        public void testReadAll_positive(List<Address> input) throws Exception {

            String uri = "http://localhost:8080/ws/address.html";
            List<?> actual = helper.setMethod(HttpMethod.GET)
                                           .requestObject(uri, List.class);
            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
        }

        @DataProvider
        private Object[][] testReadAll_positiveDP() {

            List<Address> addresses = new ArrayList<>();
            addresses.add(new Address(1, "GK colony", "Chennai", 600012));
            addresses.add(new Address(2,"Mary Street", "Salem", 631243));
            return new Object[][] { {addresses} };
        }

        @Test(dataProvider = "testSearch_positiveDP", priority = 7)
        public void testSearch_positive(List<Address> input, String[] fields, String searchInput) throws Exception {

            StringBuilder uri = new StringBuilder("http://localhost:8080/ws/address.html?searchInput=")
                                    .append(searchInput)
                                    .append("&searchField=");

            for (String field : fields) {
                uri.append(field);
                uri.append(",");
            }
            uri.substring(0, uri.length() - 1);
            List<?> actual = helper.setMethod(HttpMethod.GET)
                                           .requestObject(uri.toString(), List.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
        }

        @DataProvider
        private Object[][] testSearch_positiveDP() {

            List<Address> addresses = new ArrayList<>();
            addresses.add(new Address(1, "GK colony", "Chennai", 600012));
            String[] field = {"city", "street"};
            String searchInput = "GK";
            return new Object[][] { {addresses, field, searchInput} };
        }

        @Test(dataProvider = "testSearch_negativeDP", priority = 8)
        public void testSearch_negative(String uri, List<Error> expected) throws Exception {

            List<?> actual = helper.setMethod(HttpMethod.GET)
                                      .requestObject(uri, List.class);

            Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
        }

        @DataProvider
        private Object[][] testSearch_negativeDP() {
            List<Error> errors = new ArrayList<>();
            errors.add(Error.INVALID_URL_EXCEPTION);
            return new Object[][] {
                                  {"http://localhost:8080/ws/address.html?searchInput=&searchField=", errors},
                                  {"http://localhost:8080/ws/address.html?searchInput=", errors},
                                  {"http://localhost:8080/ws/address.html?searchInput=7.2&searchField=", errors},
                                  {"http://localhost:8080/ws/address.html?searchField=", errors},
                                  };
        }

        @AfterClass
        public void doLogout() {

        }
}