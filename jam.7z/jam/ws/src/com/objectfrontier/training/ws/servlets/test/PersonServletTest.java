package com.objectfrontier.training.ws.servlets.test;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.ws.helper.classes.HttpMethod;
import com.objectfrontier.training.ws.helper.classes.JsonUtil;
import com.objectfrontier.training.ws.helper.classes.RequestHelper;
import com.objectfrontier.training.ws.service.main.Address;
import com.objectfrontier.training.ws.service.main.Error;
import com.objectfrontier.training.ws.service.main.Person;

public class PersonServletTest extends BaseServletTest {
    RequestHelper helper;
    PersonParser parser;

    @BeforeClass
    public void setUp() {
        helper = new RequestHelper();
        parser = new PersonParser();
    }

    @Test(dataProvider = "testCreate_positiveDP", priority = 0)
    public void testCreate_positive(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person.html";
        Person person = helper.setMethod(HttpMethod.PUT)
                                  .setInput(input)
                                  .requestObject(uri, Person.class);

        input.setId(person.getId());
        Assert.assertEquals(JsonUtil.toJson(person), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testCreate_positiveDP() {

        return new Object[][] { {new Person("Ahan", "Shetty", "ahash@123", Date.valueOf("1996-09-09"), "ahan654", true,
                                     new Address(1, "Palam street", "Cbe", 698547))},
                                {new Person("Ayush", "Sharma", "ayush@763", Date.valueOf("1994-06-09"), "ayu3231", false,
                                     new Address(2, "Behl street", "Chennai", 698547))}
        };
    }


    @Test(dataProvider = "testUpdate_positiveDP", priority = 1)
    public void testUpdate_positive(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person.html";
        Person actual = helper.setMethod(HttpMethod.POST)
                                  .setInput(input)
                                  .requestObject(uri, Person.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
   }

    @DataProvider
    private Object[][] testUpdate_positiveDP() {
        return new Object[][] {
            {new Person(2, "Shashank", "Sharma", "ayush@763", Date.valueOf("1994-06-09"), "ayu3231", false,
                new Address(2,"Behl street", "Chennai", 698547))}
            };
    }

    @Test(dataProvider = "testDelete_positiveDP", priority = 2)
    public void testDelete_positive(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person.html?id=2";
        Person actual = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testDelete_positiveDP() {
        return new Object[][] {
            {new Person(2, "Shashank", "Sharma", "ayush@763", Date.valueOf("1994-06-09"), "ayu3231", false,
                    new Address(2, "Behl street", "Chennai", 698547))}
            };
    }

    @Test(dataProvider = "testDelete_negativeDP", priority = 3)
    public void testDelete_negative(String uri, List<Error> expected) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.DELETE)
                                  .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testDelete_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person.html?id", errors},
                                {"http://localhost:8080/ws/person.html?id=", errors},
                                {"http://localhost:8080/ws/person.html?id=abc", errors}
                              };
    }

    @Test(dataProvider = "testRead_positiveDP", priority = 4)
    public void testRead_positive(Person input) throws Exception {

        String uri = "http://localhost:8080/ws/person.html?id=1&includeAddress=true";
        Person actual = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri, Person.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testRead_positiveDP() {
        return new Object[][] {
            {new Person(1, "Ahan", "Shetty", "ahash@123", Date.valueOf("1996-09-09"), "ahan654", true,
                    new Address(1, "Palam street", "Cbe", 698547))}
        };
    }

    @Test(dataProvider = "testRead_negativeDP", priority = 5)
    public void testRead_negative(String uri, List<Error> expected) throws Exception {

        List<?> actual = helper.setMethod(HttpMethod.GET)
                                  .requestObject(uri, List.class);

        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] testRead_negativeDP() {
        List<Error> errors = new ArrayList<>();
        errors.add(Error.INVALID_URL_EXCEPTION);
        return new Object[][] {
                                {"http://localhost:8080/ws/person.html?id", errors},
                                {"http://localhost:8080/ws/person.html?id=", errors},
                                {"http://localhost:8080/ws/person.html?id=abc", errors}
                              };
    }

    @Test(dataProvider = "testReadAll_positiveDP", priority = 6)
    public void testReadAll_positive(List<Address> input) throws Exception {

        String uri = "http://localhost:8080/ws/person.html?includeAddress=true";
        List<?> actual = helper.setMethod(HttpMethod.GET)
                                       .requestObject(uri, List.class);
        Assert.assertEquals(JsonUtil.toJson(actual), JsonUtil.toJson(input));
    }

    @DataProvider
    private Object[][] testReadAll_positiveDP() {

        List<Person> persons = new ArrayList<>();
        persons.add(new Person(1, "Ahan", "Shetty", "ahash@123", Date.valueOf("1996-09-09"), "ahan654", true,
                new Address(1, "Palam street", "Cbe", 698547)));
        return new Object[][] { {persons} };
    }
}
