package com.objectfrontier.training.ws.servlets.test;

public class CaesarCipher {

    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    public static final int shiftCount = 5;

    public static String encrypt(String plainText, int key) {

        String cipherText = null;
        plainText = plainText.toLowerCase();
        for (int i = 0;  i < plainText.length() ; i++) {
            int charPosition = ALPHABET.indexOf(plainText.charAt(i));
            int keyValue = (shiftCount + charPosition) % 26;
            char replacedChar = ALPHABET.charAt(keyValue);
            cipherText += replacedChar;
        }
        return cipherText;
    }

    public static final String decrypt(String cipherText, int key) {

        String plainText = null;
        cipherText = cipherText.toLowerCase();
        for (int i = 0;  i < cipherText.length() ; i++) {
            int charPosition = ALPHABET.indexOf(cipherText.charAt(i));
            int keyValue = (charPosition - shiftCount) % 26;
            if (keyValue < 0) {
                keyValue = ALPHABET.length() + keyValue;
            }
            char replacedChar = ALPHABET.charAt(keyValue);
            plainText += replacedChar;
        }
        return plainText;
    }
}
