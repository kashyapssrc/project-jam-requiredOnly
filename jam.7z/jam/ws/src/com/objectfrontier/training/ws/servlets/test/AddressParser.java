package com.objectfrontier.training.ws.servlets.test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.ws.service.main.Address;
import com.objectfrontier.training.ws.service.main.AppException;
import com.objectfrontier.training.ws.service.main.Error;

public class AddressParser {

    public List<Address> parse(String fileName) {

        List<Address> addresses = new ArrayList<>();
        final String DELIMITER = ",";
        BufferedReader br;
        String line;
        try {
            br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("AddressData.csv")));

            while ((line = br.readLine()) != null) {

                String[] data = line.split(DELIMITER);
                Address address = new Address();
                address.setStreet(data[0]);
                address.setCity(data[1]);
                address.setPincode(Integer.parseInt((data[2])));
                addresses.add(address);
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
            List<Error> errors = new ArrayList<>();
            errors.add(Error.PARSER_EXCEPTION);
            throw new AppException(errors);
        }
        return addresses;
    }
}
