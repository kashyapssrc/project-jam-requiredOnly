package com.objectfrontier.training.ws.servlets.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.ws.helper.classes.JsonUtil;
import com.objectfrontier.training.ws.service.main.Address;
import com.objectfrontier.training.ws.service.main.AddressService;
import com.objectfrontier.training.ws.service.main.ConnectionManager;
import com.objectfrontier.training.ws.service.main.Error;

public class AddressServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    AddressService as = new AddressService();

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Connection connection = ConnectionManager.getConnection();
        BufferedReader reader = request.getReader();
        List<Error> errorCodes = new ArrayList<>();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        try {
            address = as.create(address, connection);
            out.write(JsonUtil.toJson(address));
        } catch (Exception e) {
            errorCodes.add(Error.INVALID_URL_EXCEPTION);
            out.write(JsonUtil.toJson(errorCodes));
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.getConnection();
        BufferedReader reader = request.getReader();
        List<String> jsonLines = reader.lines().collect(Collectors.toList());
        String addressJson = String.join("", jsonLines);
        List<Error> errorCodes = new ArrayList<>();

        Address address = JsonUtil.toObject(addressJson, Address.class);
        PrintWriter out = response.getWriter();

        try {
            address = as.update(address, connection);
            out.write(JsonUtil.toJson(address));
        } catch (Exception e) {
            errorCodes.add(Error.INVALID_URL_EXCEPTION);
            out.write(JsonUtil.toJson(errorCodes));
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Address> result = new ArrayList<>();
        response.setContentType("application/json");
        Connection connection = ConnectionManager.getConnection();
        Address address = new Address();
        String addressId = request.getParameter("id");
        String searchInput = request.getParameter("searchInput");
        String searchField = request.getParameter("searchField");
        List<Error> errorCodes = new ArrayList<>();

        PrintWriter out = response.getWriter();

        try {
            if ((searchField != null) || (searchInput != null)) {
                String[] fields = searchField.split(",");
                result = as.search(fields, searchInput, connection);
                out.write(JsonUtil.toJson(result));
            } else {
                if (Objects.isNull(addressId)) {
                    result = as.readAll(connection);
                    out.write(JsonUtil.toJson(result));
                } else {
                    long id = Long.parseLong(addressId);
                    address = as.read(id, connection);
                    out.write(JsonUtil.toJson(address));
                }
            }
        } catch (Exception e) {
            errorCodes.add(Error.INVALID_URL_EXCEPTION);
            out.write(JsonUtil.toJson(errorCodes));
            e.printStackTrace();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json");
        Connection connection = ConnectionManager.getConnection();
        String addressId = request.getParameter("id");
        List<Error> errorCodes = new ArrayList<>();
        PrintWriter out = response.getWriter();
        try {
            long id = Long.parseLong(addressId);
            Address deletedAddress = as.delete(id, connection);
            out.write(JsonUtil.toJson(deletedAddress));
        } catch (Exception e) {
            errorCodes.add(Error.INVALID_URL_EXCEPTION);
            out.write(JsonUtil.toJson(errorCodes));
            e.printStackTrace();
        }
    }
}
