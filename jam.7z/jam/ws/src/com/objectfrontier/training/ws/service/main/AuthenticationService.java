package com.objectfrontier.training.ws.service.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

public class AuthenticationService {

    public Person login(String email, String password) {
        String query = QueryManager.getPersonPasswordByEmail;
        Person person = new Person();
        ArrayList<Error> errors = new ArrayList<>();

        try {
            Connection con = ConnectionManager.getConnection();
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();

            while (result.next()) {

                person.setId(result.getLong("id"));
                person.setEmail(result.getString("email"));
                person.setAdmin(result.getBoolean("is_admin"));
            }

            if (Objects.isNull(person.getId())) {

                errors.add(Error.INVALID_CREDENTIALS);
                throw new AppException(errors);
            }
        } catch (Exception e) {
            e.printStackTrace();
            errors.add(Error.CONNECTION_ERROR);
            throw new AppException(errors);
        }
        return person;
    }}
